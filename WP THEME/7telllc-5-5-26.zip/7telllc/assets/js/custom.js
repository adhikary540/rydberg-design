(function ($) {
    "use strict";

    // Mean Menu
    $('#main-nav').stellarNav({
        theme     :'plain',
        breakpoint: 1050,
        phoneBtn:false,
        locationBtn:false,
        sticky     :false,
        openingSpeed: 250,
        closingDelay: 250,
        position:'left',
        showArrows:true,
        closeBtn     :false,
        scrollbarFix:false,
        mobileMode:false
      
      });




      //Owl Carousel banner
$('.banner-carousel').owlCarousel({
  loop: true,
  autoplay:true,
  autoplayTimeout:5000,
  margin: 0,
  dots: true,
  nav: false,
  items: 1,
  // navText: ["<i class='fa fa-arrow-left'></i>","<i class='fa fa-arrow-right'></i>"],
  animateOut: 'fadeOut',
  animateIn: 'fadeIn',
})


//Owl Carousel banner



$(document).ready(function () {
    $('.gallery-carousel').owlCarousel({
      loop: true,
      margin: 20,
      // navText: ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"],
      autoplay: true,
      responsiveClass: true,
      dots: true,
      nav: false,
      responsive: {
        0: {
          items: 2,
          nav: false
        },
        600: {
          items: 4,
          nav: false
        },
        1000: {
          items: 6,
          nav: false,
          loop: false,
          margin: 20,
        }
      }
    })
  })



$(document).ready(function () {
    $('.testi-carousel').owlCarousel({
      loop: true,
      margin: 20,
      // navText: ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"],
      autoplay: true,
      responsiveClass: true,
      dots: true,
      nav: false,
      responsive: {
        0: {
          items: 1,
          nav: false
        },
        600: {
          items: 1,
          nav: false
        },
        1000: {
          items: 1,
          nav: false,
          loop: false,
          margin: 20,
        }
      }
    })
  })





    // Go to Top
    $(function () {
        // Scroll Event
        $(window).on("scroll", function () {
            var scrolled = $(window).scrollTop();
            if (scrolled > 600) $(".go-top").addClass("active");
            if (scrolled < 600) $(".go-top").removeClass("active");
        });
        // Click Event
        $(".go-top").on("click", function () {
            $("html, body").animate({ scrollTop: "0" }, 500);
        });
    });


    // WOW Animation JS
    if ($(".wow").length) {
        var wow = new WOW({
            mobile: false,
        });
        wow.init();
    }




})(jQuery);

 