<?php
/*
* Template Name: Contact Us
*/
get_header();
?>


      
      <!-- about Section start -->
      <section class="about-split cmn-gap contact-page">
          <div class="custom-container">
            <div class="row align-items-stretch">
              <div class="col-lg-6 col-md-6 wow animate zoomIn" style="visibility: visible; animation-name: zoomIn;">
                  <div class="about-page-content">
                    <div class="row">
                             <div class="col-lg-12 col-md-12 col-12  wow animate zoomIn" style="visibility: visible; animation-name: zoomIn;">
                                 <div class="addresscard">
                                    <div class="addresscard-icon"><img class="" src="<?php bloginfo('template_url'); ?>/assets/images/phone-call.png" alt="" title=""></div>
                                    <h5>Phone Number</h5>
                                      <?php $phone_number= str_replace(array('+','(',')',' ','-'),'',get_field("phone",'option')); ?>
                                      <p><a href="tel:<?php echo $phone_number; ?>"><?php echo get_field('phone', 'option'); ?></a></p>
                                  </div>
                             </div>
                             <div class="col-lg-12 col-md-12 col-12  wow animate zoomIn" style="visibility: visible; animation-name: zoomIn;">
                                 <div class="addresscard">
                                    <div class="addresscard-icon"><img class="" src="<?php bloginfo('template_url'); ?>/assets/images/mail.png" alt="" title=""></div>
                                    <h5>Email Address</h5>
                                    <p><a href="mailto:<?php echo get_field('email', 'option'); ?>"><?php echo get_field('email', 'option'); ?></a></p>
                                  </div>
                             </div>
                             <div class="col-lg-12 col-md-12 col-12  wow animate zoomIn" style="visibility: visible; animation-name: zoomIn;">
                                 <div class="addresscard">
                                    <div class="addresscard-icon"><img class="" src="<?php bloginfo('template_url'); ?>/assets/images/location.png" alt="" title=""></div>
                                    <h5>Address</h5>
                                    <p><?php echo get_field('address', 'option'); ?></p> 
                                  </div>  
                             </div>
                         </div>
                         
                  </div> 
              </div>
              <div class="col-lg-6 col-md-6 wow animate zoomIn" style="visibility: visible; animation-name: zoomIn;">
                  <div class="about-page-content form"> 
                     <?php echo do_shortcode('[contact-form-7 id="4eefd8f" title="Contact Us Page Form"]');?> 
                 </div>  
              </div>
            </div>
         </div>
      </section>
      <!-- about Section end -->   

<?php get_footer(); ?>  