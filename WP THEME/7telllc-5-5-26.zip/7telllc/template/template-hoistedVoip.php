<?php
/*
* Template Name: Hoisted VoIP
*/
get_header();
?>

<section class="why-section cmn-gap hoisted-void">
 <div class="custom-container">
     
      <?php if( have_rows('service_contents') ):
         while( have_rows('service_contents') ) : the_row(); ?>
                        
            <div class="row">
               <div class="col-lg-12 col-md-12 col-12">
                  <div class="why-section-main-heading">  
                     <h2><?php echo get_sub_field("heading");?></h2>
                  </div>
               </div>
             </div>
            <div class="service-content"> 
                 <div class="row">
                  <div class="col-lg-7 col-md-7 col-12">
                     <div class="why-feature-content">
                           <?php echo get_sub_field("content");?> 
                     </div>
                  </div>
                  <div class="col-lg-5 col-md-5 col-12"> 
                     <div class="why-feature-image">
                          <img src="<?php echo get_sub_field("image");?>" alt="">
                     </div>
                  </div>
                 </div>
             </div> 
                
         <?php endwhile; endif;?>     
   </div>
</section>






<?php get_footer(); ?>    