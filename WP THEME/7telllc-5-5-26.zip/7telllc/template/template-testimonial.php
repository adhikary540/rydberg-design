<?php
/*
* Template Name: Testimonials
*/
get_header();
?>
<section class="why-section cmn-gap">
 <div class="custom-container">
    <div class="testi-section-header wow animate fadeInLeft">
       <?php the_content();?> 
    </div>
    <div class="testimonials"> 
        
         <?php
            $args = array(
                'posts_per_page' => -1,
                'order' => 'DESC',
                'post_type' => 'testimonial' 
            );
            $cpt_query = new WP_Query($args);
            if ($cpt_query->have_posts()) {
                $post_count = 0; // Counter for odd/even logic
                while ($cpt_query->have_posts()) {
                    $cpt_query->the_post();
            ?>
                    <div class="row testimonial">
                          <div class="col-lg-3 col-md-6 col-12 testimonial-author">
                             <img src="<?php echo get_the_post_thumbnail_url();?>" alt="Client"/>
                          </div>
                          <div class="col-lg-9 col-md-6 col-12 testi-author-text">
                             <span class="comma"><i class="fa-solid fa-quote-left"></i></span><?php the_content();?> 
                             
                             <h5><?php the_title();?></h5>
                          </div>
                       </div>
                       
            <?php 
                }
            }
            wp_reset_query();
            ?>
     </div>
 </div>
</section> 
      <!-- testi-section -->   
      
<?php get_footer(); ?> 

