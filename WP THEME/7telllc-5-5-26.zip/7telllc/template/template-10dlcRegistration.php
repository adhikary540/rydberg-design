<?php
/*
* Template Name: 10 DLC Registration
*/
get_header();
?>


<!-- about Section start -->
      <section class="about-split cmn-gap dlc-registration">
          <div class="custom-container">
            <div class="row align-items-stretch">
              <div class="col-md-12 wow animate zoomIn">
                  <div class="about-page-content">
                    <?php the_content(); ?>
                  </div> 
              </div>
            </div>
            
             <div class="row justify-content-center">
               <div class="col-lg-8" data-aos="fade-up" data-aos-delay="100">
                  <div class="accordion" id="faqAccordion">
                      
                      <?php if( have_rows('faqs') ):
                          $i=1;
                        while( have_rows('faqs') ) : the_row(); ?>
                        
                     <div class="accordion-item">
                        <h2 class="accordion-header">
                           <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faq<?php echo $i;?>">
                            <?php echo get_sub_field("faq_heading");?>
                           </button>
                        </h2>
                        <div id="faq<?php echo $i;?>" class="accordion-collapse collapse <?php if($i==1){echo 'show';} else{ }?>" data-bs-parent="#faqAccordion">
                           <div class="accordion-body">
                            <?php echo get_sub_field("faq_content");?>
                           </div>
                        </div>
                     </div>
                     
                     <?php  $i=$i+1; endwhile;endif;?> 
                     
                  </div>
               </div>
            </div>
            
         </div>
      </section>
      <!-- about Section end --> 
      
<?php get_footer(); ?>  