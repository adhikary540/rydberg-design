<?php
/*
* Template Name: Conferencing Solutions
*/
get_header();
?>

<section class="why-section cmn-gap">
 <div class="custom-container">
     
     <div class="row">
       <div class="col-lg-12 col-md-12 col-12">
          <div class="conferencing-main-content">  
             <?php the_content();?> 
          </div>
       </div>
     </div>  
     
        <div class="row">
           <div class="col-lg-12 col-md-12 col-12">
              <div class="why-section-main-heading">  
                 <h2><?php the_field('conferencing_solutions_top_section_heading');?></h2>  
              </div>
           </div>
         </div>
        <div class="service-content"> 
             <div class="row">
              <div class="col-lg-7 col-md-7 col-12">
                 <div class="why-feature-content">
                       <?php the_field('conferencing_solutions_top_section_content');?>
                 </div>
              </div>
              <div class="col-lg-5 col-md-5 col-12"> 
                 <div class="why-feature-image">
                      <img src="<?php the_field('conferencing_solutions_top_section_image');?>" alt="">
                 </div>
              </div>
             </div>
         </div>   
   </div>
</section>


<section class="why-section conferencing-solution"> 
 <div class="custom-container">
    <div class="row">
        
         <?php if( have_rows('products') ):
                        while( have_rows('products') ) : the_row(); ?>
                        
           <div class="col-lg-6 col-md-6 wow animate fadeInUp" data-wow-delay="0.1s" style="visibility: visible; animation-delay: 0.1s; animation-name: fadeInUp;"> 
                 <div class="about-grid">
                     <h4><?php echo get_sub_field("heading");?></h4>
                    <div class="about-grid-image">
                     <img src="<?php echo get_sub_field("image");?>" alt=""> 
                    </div>
                    <div class="about-grid-content">
                     <?php echo get_sub_field("content");?>   
                    </div>
                </div>
            </div>
             <?php endwhile;endif;?>
             
          </div> 
      </div>
  </section>  

<section class="why-section cmn-gap">
 <div class="custom-container">
    <div class="row">
       <div class="col-lg-12 col-md-12 col-12">
          <div class="why-section-main-heading">  
             <h2><?php the_field("conferencing_additional_content_heading");?></h2> 
          </div>
       </div>
     </div>
    <div class="service-content"> 
         <div class="row">
          <div class="col-lg-7 col-md-7 col-12">
             <div class="why-feature-content">
                   <?php the_field("conferencing_additional_content");?> 
             </div>
          </div>
          <div class="col-lg-5 col-md-5 col-12"> 
             <div class="why-feature-image">
                  <img src="<?php the_field("conferencing_additional_content_image");?>" alt="">
             </div>
          </div>
         </div>
     </div>   
   </div>
</section>  

<section class="why-section bullet-points">
 <div class="custom-container">
    <div class="row">
        
         <?php if( have_rows('bullet_points') ):
                        while( have_rows('bullet_points') ) : the_row(); ?>
                        
           <div class="col-lg-6 col-md-6 wow animate fadeInUp" data-wow-delay="0.1s" style="visibility: visible; animation-delay: 0.1s; animation-name: fadeInUp;"> 
                 <div class="about-grid">
                     <h4><?php echo get_sub_field("heading");?></h4> 
                    <div class="about-grid-content">
                     <?php echo get_sub_field("content");?>    
                    </div>
                </div>
            </div>
             <?php endwhile;endif;?>
             
          </div> 
      </div>
  </section>  


<?php get_footer(); ?>    