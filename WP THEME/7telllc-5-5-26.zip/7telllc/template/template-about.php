<?php
/*
* Template Name: About Us
*/
get_header();
?>

<!-- about Section start -->
      <section class="about-split cmn-gap">
          <div class="custom-container">
            <div class="row align-items-stretch">
              <div class="col-md-12 wow animate zoomIn">
                  <div class="about-page-content">
                    <?php the_content(); ?>
                  </div> 
              </div>
            </div>
         </div>
      </section>
      <!-- about Section end -->    
      
      <section class="why-section about-page">
         <div class="custom-container">
            <div class="row">
                   <div class="col-lg-6 col-md-6 wow animate fadeInUp" data-wow-delay="0.1s" style="visibility: visible; animation-delay: 0.1s; animation-name: fadeInUp;"> 
                         <div class="about-grid">
                            <div class="about-grid-image">
                             <img src="<?php the_field('about_left_section_image');?>" alt="">
                            </div>
                            <div class="about-grid-content">
                               <h4><?php the_field('about_left_section_heading');?></h4>
                               <?php the_field('about_left_section_content');?>
                            </div>
                        </div>
                    </div>
                   <div class="col-lg-6 col-md-6 wow animate fadeInUp" data-wow-delay="0.4s" style="visibility: visible; animation-delay: 0.4s; animation-name: fadeInUp;">
                     <div class="about-grid"> 
                        <div class="about-grid-image">
                         <img src="<?php the_field('about_right_section_image');?>" alt=""> 
                        </div>
                        <div class="about-grid-content"> 
                           <h4><?php the_field('about_right_section_heading');?></h4>
                           <?php the_field('about_right_section_content');?>
                        </div> 
                     </div>
                    </div> 
                  </div> 
              </div>
          </section>  

<?php get_footer(); ?>  