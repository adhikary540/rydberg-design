<?php
/*
* Template Name: Our Network
*/
get_header();
?>

<!-- about Section start -->
      <section class="about-split cmn-gap">
          <div class="custom-container">
            <div class="row align-items-stretch">
              <div class="col-md-12 wow animate zoomIn">
                  <div class="about-page-content">
                    <?php the_content(); ?>
                  </div> 
              </div>
            </div>
         </div>
      </section>
      <!-- about Section end -->    

<?php get_footer(); ?>   