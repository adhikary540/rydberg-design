<?php
/*
* Template Name: Career
*/
get_header();
?>

<!-- about Section start -->
      <section class="about-split cmn-gap career-page">
          <div class="custom-container">
            <div class="row align-items-stretch">
              <div class="col-lg-6 col-md-6 wow animate zoomIn" style="visibility: visible; animation-name: zoomIn;">
                  <div class="about-page-content">
                    <?php the_content(); ?>
                  </div> 
              </div>
              <div class="col-lg-6 col-md-6 wow animate zoomIn" style="visibility: visible; animation-name: zoomIn;">
                  <div class="about-page-content form"> 
                     <?php echo do_shortcode('[contact-form-7 id="ac9bbcf" title="Contact form 1"]');?> 
                 </div>  
              </div>
            </div>
            
            <div class="row align-items-stretch">
              <div class="col-lg-12 col-md-12 wow animate zoomIn" style="visibility: visible; animation-name: zoomIn;">
                  <div class="about-page-content">
                      <?php the_field('additional_content');?>
                    </div>
                </div>
            </div>
            
         </div>
      </section>
      <!-- about Section end -->     

<?php get_footer(); ?>   