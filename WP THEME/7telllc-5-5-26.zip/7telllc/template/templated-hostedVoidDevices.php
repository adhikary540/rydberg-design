<?php
/*
* Template Name: Hosted Void Devices
*/
get_header();
?>

<section class="why-section cmn-gap void-devices">
 <div class="custom-container">
    <div class="row">
        
        
        <?php
                    $args = array(
                        'posts_per_page' => -1,
                        'order' => 'DESC',
                        'post_type' => 'service' 
                    );
                    $cpt_query = new WP_Query($args);
                    if ($cpt_query->have_posts()) {
                        $i=1;
                        while ($cpt_query->have_posts()) {
                            $cpt_query->the_post();
                  ?> 
                                 
             <div class="col-lg-4 col-md-6 wow animate fadeInUp" data-wow-delay="0.<?php echo $i;?>s" style="visibility: visible; animation-delay: 0.<?php echo $i;?>s; animation-name: fadeInUp;"> 
                 <div class="about-grid">
                     <h4><?php the_title();?></h4>
                        <div class="about-grid-image">
                         <img src="<?php echo get_the_post_thumbnail_url();?>" alt=""> 
                        </div>
                        <div class="about-grid-content">
                           <p><?php 
                            $excerpt = get_the_excerpt();
                            $words = explode(' ', $excerpt);
                            echo implode(' ', array_slice($words, 0, 20)) . '...';
                            ?> </p> 
                        </div>
                        <a href="<?php the_permalink();?>" class="cmn-butn red-butn">
                                   Read More<span><img src="https://shyamfuture.in/7tel-llc/dev/wp-content/themes/7telllc/assets/images/butn-arrow1.png" alt=""></span>
                               </a>
                    </div>
             </div>
            
            <?php 
              $i=$i+3; 
               }
             } 
             wp_reset_query();?>  
             
                          
          </div> 
      </div>
  </section>


<?php get_footer(); ?>    