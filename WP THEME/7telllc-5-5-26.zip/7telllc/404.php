<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package WordPress
 * @subpackage Twenty_Nineteen
 * @since Twenty Nineteen 1.0
 */

get_header();
?>

	<!-- about Section start -->
      <section class="about-split cmn-gap">
          <div class="custom-container">
            <div class="row align-items-stretch">

			<div class="error-404 not-found">
				<header class="page-header">
					<h1 class="page-title"><?php _e( '404! Page not found.', 'twentynineteen' ); ?></h1>
				</header><!-- .page-header -->

				<div class="page-content">
					<p><br><?php _e( 'It looks like nothing was found at this location. Maybe try a search?', 'twentynineteen' ); ?></p> 
				</div><!-- .page-content -->
			</div><!-- .error-404 -->

		</div>
	</div>
 </section> 

<?php
get_footer();
