<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage Twenty_Nineteen
 * @since Twenty Nineteen 1.0
 */

get_header();
?>

<!-- about Section start -->
      <section class="about-split cmn-gap single-service">
          <div class="custom-container">
            <div class="row align-items-stretch">
                
                 <?php if ( has_post_thumbnail() ) { ?> 
                 <div class="col-lg-4 col-md-4 wow animate zoomIn">
                      <div class="service-image">
                        <img src="<?php echo get_the_post_thumbnail_url();?>" alt=""> 
                      </div> 
                   </div> 
                  <div class="col-lg-8 col-md-8 wow animate zoomIn">
                      <div class="about-page-content">
                        <?php the_content(); ?>
                      </div> 
                   </div>
                  <?php } else { ?>
                    <div class="col-lg-12 col-md-12 wow animate zoomIn">
                      <div class="about-page-content">
                        <?php the_content(); ?>
                      </div> 
                   </div>
                 <?php } ?>  
             
            </div>
         </div>
      </section>
      <!-- about Section end --> 
<?php
get_footer();
