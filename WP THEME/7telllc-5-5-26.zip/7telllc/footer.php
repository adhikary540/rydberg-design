<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Nineteen
 * @since Twenty Nineteen 1.0
 */

?>

<!-- cta-section-->
      <section class="cta-section">
         <div class="custom-container">
            <div class="cta-section-inner">
               <h2><?php the_field('contact_section_heading', 85);?></h2>
               <p><?php the_field('contact_section_content', 85);?></p>
               
               <?php 
                  $link11 = get_field("contact_section_button_link",85);
                  if( $link11 ): 
                	$link_url11 = $link11['url'];
                	$link_title11 = $link11['title'];
                	$link_target11 = $link11['target'] ? $link11['target'] : '_self';
                 ?>
                   <a href="<?php echo esc_url( $link_url11 ); ?>" target="<?php echo esc_attr( $link_target11 ); ?>" class="cmn-butn red-butn">
                	   <?php echo esc_html( $link_title11 ); ?>
                	   <span><img src="<?php bloginfo('template_url'); ?>/assets/images/butn-arrow1.png" alt=""></span>
                   </a>
              <?php endif; ?> 

            </div>
         </div>
      </section>
      <!-- cta-section-->
      <footer>
         <div class="custom-container">
            <div class="row">
               <!-- Brand -->
               <div class="col-lg-3 col-md-6 col-12">
                  <div class="footer-logo">
                     <a href="<?php bloginfo('url'); ?>">
                         <img src="<?php echo get_field("footer_logo",'option');?>" alt="7Tel"/> 
                     </a> 
                  </div>
                  <p class="foot-desc"> <?php echo get_field("footer_text",'option');?></p> 
                  
                  <div class="footer-social">
                     <a href="<?php echo get_field("facebook_link",'option');?>" class="soc-btn" target="_blank"><i class="fab fa-facebook-f"></i></a>
                     <a href="<?php echo get_field("instagram_link",'option');?>" class="soc-btn" target="_blank"><i class="fab fa-instagram"></i></a>
                     <a href="<?php echo get_field("twitter_link",'option');?>" class="soc-btn" target="_blank"><i class="fab fa-twitter"></i></a>
                  </div>
               </div>
               <!-- Company -->
               <div class="col-lg-3 col-md-6 col-6">
                  <div class="footer-col-title">Company</div>
                   <?php wp_nav_menu(array('theme_location'=>'footer','menu_class'=>'footer-links','container_class'=>'','container'=>'')); ?>   
               </div>
               <!-- Help -->
               <div class="col-lg-3 col-md-6 col-6">
                  <div class="footer-col-title">Help</div>
                  <?php wp_nav_menu(array('theme_location'=>'policy','menu_class'=>'footer-links','container_class'=>'','container'=>'')); ?>  
               </div>
               <!-- Newsletter -->
               <div class="col-lg-3 col-md-6 col-12">
                  <div class="footer-col-title">Subscribe to Newsletter</div>
                     <form class="footer-newsletter-input" method="post" action="<?php echo esc_url( home_url( '/' ) ); ?>?na=s" onsubmit="return newsletter_check(this)">
                         <input type="email" name="ne" required placeholder="Your email address…"/> 
                         <button type="submit">Join</button>
                     </form>
               </div>
            </div>
         </div>
         <!-- Giant watermark text -->
         <div class="footer-big-text"><?php echo get_field("footer_get_in_touch_text",'option');?></div>
         <div class="footer-bottom">
            <div class="container">
               <p class="footer-bottom-copy">Copyright  <?php echo date("Y");?> <a href="<?php bloginfo('url'); ?>"> <?php bloginfo('title'); ?></a> All rights reserved.</p>
            </div>
         </div>
      </footer>
      <!-- footer-section -->
      <div class="go-top active">
         <i class="fa fa-angle-double-up" aria-hidden="true"></i>
      </div>
      
      
      <script>
         jQuery(window).scroll(function () {
           if (jQuery(this).scrollTop() > 50) {
             jQuery(".header-section").addClass("scroll");
           } else {
             jQuery(".header-section").removeClass("scroll");
           }
         });
      </script>     

<?php wp_footer(); ?>  

</body>
</html>
