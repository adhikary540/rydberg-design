<?php
/**
 * The front page template file
 *
 * If the user has selected a static page for their homepage, this is what will
 * appear.
 * Learn more: https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since Twenty Seventeen 1.0
 * @version 1.0
 */

get_header(); ?> 


 <!-- gallery-section -->
      <section class="trusted-strip cmn-gap"> 
         <div class="custom-container">
            <h3><?php the_field('trusted_by_section_heading');?></h3>
            <div class="gallery-carousel owl-carousel position-relative">
                
                  <?php
			    	if (get_field('trusted_by_section_images')): ?>
				    <?php while (has_sub_field('trusted_by_section_images')): ?>
                   <div class="gallery-card">
                      <img
                         src="<?php the_sub_field("image"); ?>"
                         data-gallery="portfolioGallery"
                         class="portfokio-lightbox"
                         />
                   </div>
                   <?php endwhile; ?>
    			<?php endif; ?>
    			
            </div>
         </div>
      </section>
      <!-- gallery-section -->
      
      <!-- about-split -->
      <section class="about-split cmn-gap">
         <div class="custom-container">
            <div class="row  align-items-stretch">
               <!-- Left: World-class text + image -->
               <div class="col-lg-3 col-md-3 co-12">
                  <div class="about-split-left">
                     <div class="about-split-left-tittle">
                        <?php the_field('left_about_content');?>
                        
                         <?php 
                              $link4 = get_field("left_about_button");
                              if( $link4 ): 
                            	$link_url4 = $link4['url'];
                            	$link_title4 = $link4['title'];
                            	$link_target4 = $link4['target'] ? $link4['target'] : '_self';
                            ?>
                           <a href="<?php echo esc_url( $link_url4 ); ?>" target="<?php echo esc_attr( $link_target4 ); ?>" class="cmn-butn red-butn">
                        	   <?php echo esc_html( $link_title4 ); ?>
                        	   <span><img src="<?php bloginfo('template_url'); ?>/assets/images/butn-arrow1.png" alt=""></span>
                           </a>
                        <?php endif; ?>  

                     </div>
                     <div class="market-chip">
                        <?php the_field('left_about_snippet');?>
                     </div>
                  </div>
               </div>
               <div class="col-lg-6 col-md-6 co-12">
                  <div class="about-img-wrap">
                     <img src="<?php the_field('about_center_image');?>" alt="World Class Comms">
                  </div>
               </div>
               <!-- Right: Enterprise card + about image -->
               <div class="col-lg-3 col-sm-3 col-12">
                  <div class="about-right-card">
                     <div class="about-right-card-header">
                        <?php the_field('about_right_content');?>
                     </div>
                     <div class="about-thumb">
                        <img src="<?php the_field('about_right_image');?>" alt="About 7Tel">
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!--about-split -->
      
      <!-- services-section -->
      <section class="services-section cmn-gap">
         <div class="custom-container">
            <div class="services-section-header">
               <div class="row">
                  <div class="col-lg-3 col-md-3 col-12">
                     <div class="services-header-left">
                        <h6><?php the_field('services_section_snippet_text');?></h6>
                        
                        <?php 
                          $link5 = get_field("services_section_link");
                          if( $link5 ): 
                        	$link_url5 = $link5['url'];
                        	$link_title5 = $link5['title'];
                        	$link_target5 = $link5['target'] ? $link5['target'] : '_self';
                        ?>
                           <a href="<?php echo esc_url( $link_url5 ); ?>" target="<?php echo esc_attr( $link_target5 ); ?>" class="cmn-butn red-butn">
                        	   <?php echo esc_html( $link_title5 ); ?>
                        	   <span><img src="<?php bloginfo('template_url'); ?>/assets/images/butn-arrow1.png" alt=""></span>
                           </a>
                        <?php endif; ?> 

                     </div>
                  </div>
                  <div class="col-lg-9 col-md-9 col-12">
                     <div class="services-header-right">
                        <h2><?php the_field('services_section_heading');?></h2> 
                     </div>
                  </div>
               </div>
            </div>
            <div class="row">
                
                <?php
                    $args = array(
                        'posts_per_page' => 3,
                        'order' => 'ASC',
                        'post_type' => 'service' 
                    );
                    $cpt_query = new WP_Query($args);
                    if ($cpt_query->have_posts()) {
                        $i=1;
                        while ($cpt_query->have_posts()) {
                            $cpt_query->the_post();
                  ?> 
                  <div class="col-lg-4 col-md-6 col-12 wow animate fadeInUp" data-wow-delay="0.<?php echo $i;?>s" style="visibility: visible; animation-delay: 0.<?php echo $i;?>s; animation-name: fadeInUp;">
                  <div class="service-card">
                     <a href="<?php the_permalink();?>">
                        <div class="service-arrow"><i class="fa-solid fa-arrow-right"></i></div>
                     </a>
                     <h3><?php the_title();?></h3>
                     <?php the_content();?> 
                  </div>
               </div> 
              <?php 
              $i=$i+3; }} wp_reset_query();?> 
                  
            </div>
         </div>
      </section>
      <!-- services-section -->
      
      <!-- why-section -->
      <section class="why-section cmn-gap">
         <div class="custom-container">
            <div class="row">
               <div class="col-lg-12 col-md-12 col-12">
                  <div class="why-img-wrap">
                     <img src="<?php the_field('why_choose_us_section_image');?>" alt="Why Choose 7Tel">
                  </div>
               </div>
               <div class="col-lg-12 col-md-12 col-12">
                  <div class="why-section-tittle">
                     <h6><?php the_field('why_choose_us_sub_heading');?></h6>
                     <h2><?php the_field('why_choose_us_heading');?></h2>
                  </div>
               </div>
               <div class="row">
                   
                   <?php
			    	if (get_field('why_choose_us_content')): ?>
				    <?php while (has_sub_field('why_choose_us_content')): ?>
                      <div class="col-md-6">
                         <div class="why-feature">
                            <div class="why-check"><i class="fa-solid fa-check"></i></div>
                            <div>
                               <h6><?php the_sub_field('heading'); ?></h6>
                               <p><?php the_sub_field('content'); ?></p>
                            </div>
                         </div>
                      </div>
                      <?php endwhile; ?>
				   <?php endif; ?> 
				   
               </div>
            </div>
         </div>
      </section>
      <!-- why-section -->
      <!-- testi-section -->
      <section class="testi-section">
         <div class="custom-container">
            <div class="testi-header">
               <div class="testi-header-left">
                  <h6><?php the_field('testimonial_subheading');?></h6>
                  <h2><?php the_field('testimonial_heading');?></h2>
               </div>
               <?php 
                  $link6 = get_field("testimonial_link");
                  if( $link6 ): 
                	$link_url6 = $link6['url'];
                	$link_title6 = $link6['title'];
                	$link_target6 = $link6['target'] ? $link6['target'] : '_self';
                ?>
                   <a href="<?php echo esc_url( $link_url6 ); ?>" target="<?php echo esc_attr( $link_target6 ); ?>" class="cmn-butn red-butn">
                	   <?php echo esc_html( $link_title6 ); ?>
                	   <span>
                	   <img src="<?php bloginfo('template_url'); ?>/assets/images/butn-arrow1.png" alt=""></span>
                   </a>
                <?php endif; ?>

            </div>
            <div class="row">
               <div class="col-lg-5 col-md-5 col-12">
                  <div class="testi-section-img">
                     <img src="<?php the_field('testimonial_left_image');?>" alt=""> 
                  </div>
               </div>
               <div class="col-lg-7 col-md-7 col-12">
                  <div class="testi-carousel owl-carousel" data-aos="fade-up" data-aos-delay="80">
                      
                      
                      <?php
                    $args = array(
                        'posts_per_page' => -1,
                        'order' => 'DESC',
                        'post_type' => 'testimonial' 
                    );
                    $cpt_query = new WP_Query($args);
                    if ($cpt_query->have_posts()) {
                        while ($cpt_query->have_posts()) {
                            $cpt_query->the_post();
                  ?>
                  
                  <div class="testi-card">
                        <div class="testi-body">
                           <div class="testi-stars">
                              <i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
                              <i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
                              <i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>
                           </div>
                           <?php the_content();?> 
                           <div class="testi-info">
                              <div class="testi-img">
                                 <img src="<?php echo get_the_post_thumbnail_url();?>" alt="Client"/> 
                              </div>
                              <div class="testi-author">
                                 <h5><?php the_title();?></h5>
                                 <?php the_excerpt();?>  
                              </div>
                           </div>
                        </div>
                     </div>
                  
                  <?php } } wp_reset_query();?> 
                  
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- testi-section -->
      
      <!-- industry-section -->
      <section class="industry-section cmn-gap">
         <div class="custom-container">
            <div class="industry-section-header">
               <h6><?php the_field('industry_section_sub_heading');?></h6>
               <h2><?php the_field('industry_section_heading');?></h2>
            </div>
            <div class="row">
                <?php
			    	if (get_field('industry_section_content')): ?>
				    <?php while (has_sub_field('industry_section_content')): 
				   ?>
					   
				   <div class="col-lg-4 col-md-4 col-12 wow animate fadeInUp">
                      <div class="industry-card">
                         <h5><?php the_sub_field('heading'); ?></h5>
                         <p><?php the_sub_field('content'); ?></p>
                      </div>
                   </div>
				   
				   <?php endwhile; ?>
			   <?php endif; ?>
			   
            </div>
         </div>
      </section>
      <!-- industry-section -->
      
      <!-- pricing-section-->
      <section class="pricing-section cmn-gap">
         <div class="custom-container">
            <div class="row align-items-start">
               <!-- Left -->
               <div class="col-lg-5 col-md-5 col-12">
                  <div class="pricing-section-left">
                     <h6><?php the_field('pricing_section_sub_heading');?></h6>
                     <h2><?php the_field('pricing_section_heading');?></h2>
                     
                     <?php 
                      $link7 = get_field("pricing_section_button");
                      if( $link7 ): 
                    	$link_url7 = $link7['url'];
                    	$link_title7 = $link7['title'];
                    	$link_target7 = $link7['target'] ? $link7['target'] : '_self';
                    ?>
                       <a href="<?php echo esc_url( $link_url7 ); ?>" target="<?php echo esc_attr( $link_target7 ); ?>" class="cmn-butn red-butn">
                    	   <?php echo esc_html( $link_title7 ); ?>
                    	   <span><img src="<?php bloginfo('template_url'); ?>/assets/images/butn-arrow1.png" alt=""></span>
                       </a>
                    <?php endif; ?>

                  </div>
               </div>
               <!-- Right info box -->
               <div class="col-lg-7 col-md-7 col-12">
                  <div class="pricing-info-box">
                     <div class="pricing-info-box-left">
                        <?php the_field('professional_plan_content');?>
                        <h4> <?php the_field('professional_plan_price');?> / <span>project</span></h4>
                        
                        <div class="pricing-butn">
                            <?php 
                              $link8 = get_field("professional_plan_link");
                              if( $link8 ): 
                            	$link_url8 = $link8['url'];
                            	$link_title8 = $link8['title'];
                            	$link_target8 = $link8['target'] ? $link8['target'] : '_self';
                            ?>
                               <a href="<?php echo esc_url( $link_url8 ); ?>" target="<?php echo esc_attr( $link_target8 ); ?>" class="cmn-butn red-butn">
                            	   <?php echo esc_html( $link_title8 ); ?>
                            	   <span><img src="<?php bloginfo('template_url'); ?>/assets/images/butn-arrow1.png" alt=""></span>
                               </a>
                            <?php endif; ?>
                           
                        </div>
                        
                     </div>
                     <div class="pricing-info-box-right">
                        <?php the_field('professional_plan_right_content');?>
                        <div class="pricing-info-box-right-butn">
                           
                           <?php 
                              $link9 = get_field("professional_plan_right_link");
                              if( $link9 ): 
                            	$link_url9 = $link9['url'];
                            	$link_title9 = $link9['title'];
                            	$link_target9 = $link9['target'] ? $link9['target'] : '_self';
                            ?>
                               <a href="<?php echo esc_url( $link_url9 ); ?>" target="<?php echo esc_attr( $link_target9 ); ?>" class="nav-arrow">
                            	   <i class="fa-solid fa-arrow-right"></i>
                               </a>
                            <?php endif; ?> 
                            
                        </div> 
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- pricing-section-->
      <!-- careers-section-->
      <section class="careers-section">
         <div class="custom-container">
            <div class="careers-bg"></div>
            <div class="careers-content wow animate fadeInUp">
               <h3><?php the_field('career_section_heading');?></h3>
               <p><?php the_field('career_section_content');?></p>
               
               <?php 
                  $link10 = get_field("header_contact_link",'option');
                  if( $link10 ): 
                	$link_url10 = $link10['url'];
                	$link_title10 = $link10['title'];
                	$link_target10 = $link10['target'] ? $link10['target'] : '_self';
                ?>
                   <a href="<?php echo esc_url( $link_url10 ); ?>" target="<?php echo esc_attr( $link_target10 ); ?>" class="cmn-butn btn-explore">
                	   <?php echo esc_html( $link_title10 ); ?>
                   </a>
                <?php endif; ?>
            </div>
         </div>
      </section>
      <!-- careers-section-->

         
<?php
get_footer();
?> 