<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Nineteen
 * @since Twenty Nineteen 1.0
 */

?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<link rel="profile" href="https://gmpg.org/xfn/11" />
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<!-- header -->
      <header class="header-section">
         <div class="custom-container">
            <div class="header-section-inner">
               <section class="logo-row">
                  <div class="logo">
                     <a href="<?php bloginfo('url'); ?>"
                        ><img src="<?php echo get_field("header_logo",'option');?>" alt="logo"
                        /></a>
                  </div>
               </section>
               <section class="nav-row">
                 
                     <div class="nav-inner">
                        
                          
                           
                           <?php wp_nav_menu( array( 'menu' => 'main-menu', 'container_class' => 'stellarnav left desktop', 'container_id'  => 'main-nav' ,'add_li_class'  => 'drop-left' ) ); ?>
                           
                        
                        <div class="rightlink">
                            <?php 
                              $link1 = get_field("header_contact_link",'option');
                             if( $link1 ): 
                                $link_url1 = $link1['url'];
                                $link_title1 = $link1['title'];
                                $link_target1 = $link1['target'] ? $link1['target'] : '_self';
                            ?>
                               <a href="<?php echo esc_url( $link_url1 ); ?>" target="<?php echo esc_attr( $link_target1 ); ?>" class="cmn-butn red-butn">
                                   <?php echo esc_html( $link_title1 ); ?><span><img src="<?php bloginfo('template_url'); ?>/assets/images/butn-arrow1.png" alt=""></span>
                               </a>
                            <?php endif; ?>
                    
                        </div>
                     </div>
                  
               </section>
            </div>
         </div>
      </header>
      <!-- header -->
      
      <?php if ( is_front_page() ) : ?>
      <!-- banner-section -->
      <section class="banner-section">
         <div class="row">
            <div class="col-lg-7 col-md-7 col-12 p-0">
               <div class="banner-left">
                  <img src="<?php the_field('banner_section_left_image');?>" alt="" /> 
                  <div class="hero-slide-overlay"></div>
                  <div class="hero-content">
                     <h1><?php the_field('banner_heading');?></h1> 
                     <p><?php the_field('banner_content');?></p> 
                     <div class="hero-btns-row">
                         
                         <?php 
                          $link2 = get_field("banner_button_one");
                          if( $link2 ): 
                        	$link_url2 = $link2['url'];
                        	$link_title2 = $link2['title'];
                        	$link_target3 = $link2['target'] ? $link2['target'] : '_self';
                        ?>
                           <a href="<?php echo esc_url( $link_url2 ); ?>" target="<?php echo esc_attr( $link_target3 ); ?>" class="cmn-butn white-butn">
                        	   <?php echo esc_html( $link_title2 ); ?>
                        	   <span><img src="<?php bloginfo('template_url'); ?>/assets/images/butn-arrow2.png" alt=""></span>
                           </a>
                        <?php endif; ?>
                        
                        <?php 
                          $link3 = get_field("banner_button_two"); 
                          if( $link3 ): 
                        	$link_url3 = $link3['url'];
                        	$link_title3 = $link3['title'];
                        	$link_target3 = $link3['target'] ? $link3['target'] : '_self';
                        ?>
                           <a href="<?php echo esc_url( $link_url3 ); ?>" target="<?php echo esc_attr( $link_target3 ); ?>" class="cmn-butn red-butn">
                        	   <?php echo esc_html( $link_title3 ); ?>
                        	   <span><img src="<?php bloginfo('template_url'); ?>/assets/images/butn-arrow1.png" alt=""></span>
                           </a>
                        <?php endif; ?>
                        
                     </div>
                  </div>
                  <div class="hero-stats">
                      
                      <?php
    			    	if (get_field('banner_snippets')): ?>
    				    <?php while (has_sub_field('banner_snippets')): ?>
				    
                             <div class="hero-stat-item">
                                <div class="hero-stat-num"><?php the_sub_field("heading"); ?></div>
                                <div class="hero-stat-label"><?php the_sub_field("sub_heading"); ?></div>
                             </div>
                     
                         <?php endwhile; ?>
			        <?php endif; ?>
			        
                  </div>
               </div>
            </div>
            <div class="col-lg-5 col-md-5 col-12 p-0">
               <div class="banner-right">
                  <img src="<?php the_field('banner_section_right_image');?>" alt="" />
               </div>
            </div>
         </div>
      </section>
      <!-- banner-section -->
      <?php else: ?>
       <!-- banner-section -->
      <section class="inner-banner-section">
         <div class="row">
            <div class="col-lg-12 col-md-12 col-12 p-0">
               <div class="banner-left-inner">
                      <?php if ( has_post_thumbnail() ) { ?>
                         <img src="<?php echo get_the_post_thumbnail_url();?>" alt="">
                      <?php } else { ?>
                        <img src="<?php bloginfo('template_url'); ?>/assets/images/banner-inner-7tel.png" alt="" />
                      <?php } ?> 
                  <div class="hero-slide-overlay"></div>
                  <div class="hero-content-inner"> 
                     <h1><?php the_title();?></h1> 
                  </div> 
               </div>
            </div> 
         </div>
      </section>
      <!-- banner-section -->
       <?php endif; ?> 
