// Stellar Nav
jQuery(document).ready(function($) {
    jQuery('.stellarnav').stellarNav({
        theme: 'dark',
        breakpoint: 5000,
        position: 'right',
        // phoneBtn: '18009997788',
        // locationBtn: 'https://www.google.com/maps'
    });
});

jQuery('#HeaderSlider').owlCarousel({
    loop: true,
    margin: 0,
    dots: false,
    nav: false,
    autoplay:true,
    autoplayTimeout:3000,
    margin:20,
    center:true,
    items: 1,
    responsive: {
    0: {
      items: 1
    },

    600: {
      items: 1
    },

    1024: {
      items: 1
    },

    1366: {
      items: 1
    }
  }
})







   jQuery(document).ready(function ($) {
    $('#bannerSlider').owlCarousel({
      loop: true,
      margin: 5,
      navText: ["<img src='images/left-arrow.png'>","<img src='images/righjt-arrow.png'>"],
      autoplay: true,
      responsiveClass: true,
      responsive: {
        0: {
          items: 1,
          nav: true
        },
        600: {
          items: 1,
          nav: true
        },
        1000: {
          items: 1,
          nav: true,
          loop: false,
          margin: 1,
        }
      }
    });
    
    $('#clientstoriesSlider').owlCarousel({
      loop: true,
      margin: 5,
      navText: ["<i class='fa-solid fa-angle-left'></i>","<i class='fa-solid fa-angle-right'></i>"],
      autoplay: true,
      responsiveClass: true,
      dots:false,
      responsive: {
        0: {
          items: 1,
          nav: true
        },
        600: {
          items: 1,
          nav: true
        },
        1000: {
          items: 1,
          nav: true,
          loop: false,
          margin: 1,
        }
      }
    })
  })















// Sticky Header Script
// var header = document.querySelector('.header');
// onScroll = () => {
//   var scrolledPage = Math.round(window.pageYOffset);
//   if(scrolledPage > 60) {
//     header.classList.add('sticky');
//   } else {
//     header.classList.remove('sticky');
//   }
// }
// document.addEventListener('scroll', onScroll); 

//
// window.addEventListener('load', function() {
//     const boxes = document.querySelectorAll('.event-wrap .event-box');
//     let maxHeight = 0;

//     // Reset heights
//     boxes.forEach(box => {
//         box.style.height = 'auto'; // Reset height to auto to get natural height
//     });

//     // Find the maximum height
//     boxes.forEach(box => {
//         maxHeight = Math.max(maxHeight, box.offsetHeight);
//     });

//     // Set all boxes to the maximum height
//     boxes.forEach(box => {
//         box.style.height = `${maxHeight}px`;
//     });
// });


// AOS Js
// AOS.init({
//     easing: 'ease-in-out-sine'
//   });

// Go to Top
jQuery(function () {
  // Scroll Event
  jQuery(window).on("scroll", function () {
      var scrolled = jQuery(window).scrollTop();
      if (scrolled > 600) jQuery(".go-top").addClass("active");
      if (scrolled < 600) jQuery(".go-top").removeClass("active");
  });
  // Click Event
  jQuery(".go-top").on("click", function () {
      jQuery("html, body").animate({ scrollTop: "0" }, 500);
  });
});






// Sticky Header on Scroll js
const header = document.querySelector("header");
const toggleClass = "is-sticky";

window.addEventListener("scroll", () => {
  const currentScroll = window.pageYOffset;
  if (currentScroll > 150) {
    header.classList.add(toggleClass);
  } else {
    header.classList.remove(toggleClass);
  }
});




// WOW Animation JS
  if (jQuery(".wow").length) {
      var wow = new WOW({
          mobile: false,
      });
      wow.init();
  }










//Lodear js
// setTimeout(function(){
//   $('body').addClass('loaded');
// }, 2000);






jQuery(document).ready(function($) {
    $('#close-btn').click(function() {
        $('#search-overlay').fadeOut();
        $('#search-btn').show();
        $('body').css('overflow', ''); // Reset body overflow
    });
    
    $('#search-btn').click(function() {
        // $(this).hide();
        $('#search-overlay').fadeIn();
        $('body').css('overflow', 'hidden'); // Prevent body scrolling
    });
});













