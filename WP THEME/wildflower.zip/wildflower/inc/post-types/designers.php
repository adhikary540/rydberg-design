<?php
/***
* designers Post Type
***/

if(! class_exists('Progressive_designers_Post_Type')):
class Progressive_designers_Post_Type{

	function __construct(){
		// Adds the designers post type and taxonomies
		add_action('init',array(&$this,'designers_init'),0);
		// Thumbnail support for designers posts
		add_theme_support('post-thumbnails',array('designers'));
	}

	function designers_init(){
		/**
		 * Enable the designers_init custom post type
		 * http://codex.wordpress.org/Function_Reference/register_post_type
		 */
		$labels = array(
			'name'					=> __('Designers','Progressive'),
			'singular_name'		=> __('Designer Name','Progressive'),
			'add_new'				=> __('Add New','Progressive'),
			'add_new_item'			=> __('Add New Designer','Progressive'),
			'edit_item'			=> __('Edit Designer','Progressive'),
			'new_item'				=> __('Add New Designer','Progressive'),
			'view_item'			=> __('View Designer','Progressive'),
			'search_items'			=> __('Search Designers','Progressive'),
			'not_found'			=> __('No Designers items found','Progressive'),
			'not_found_in_trash'	=> __('No Designers found in trash','Progressive')
		);
		
		$args = array(
		    'labels' => $labels,
			'public' => true,
			'publicly_queryable' => true,
			'show_ui' => true,
			'query_var' => true,
			'menu_icon' => 'dashicons-smiley',
			'rewrite' => true,			
			'map_meta_cap' => true,
			'hierarchical' => false,
			'menu_position' => 5,
			'supports' => array('title', 'thumbnail', 'editor', 'excerpt', 'page-attributes')
		); 
		
		$args = apply_filters('Progressive_designers_args',$args);
		register_post_type('designers',$args);
	}
}
new Progressive_designers_Post_Type;
endif;