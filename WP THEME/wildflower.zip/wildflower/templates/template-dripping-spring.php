<?php
/*
* Template Name: Template Dripping Spring
*/
get_header();
?>
<?php if(have_posts()): while(have_posts()): the_post(); ?>
 
<div class="dripping-spring-main-sec">
 	<div class="container">
        <div class="row align-items-center">
           	<div class="col-md-12 col-sm-12">
              	<div class="dripping-content">
                 	<img src="<?php echo get_field('wildflower_footer_logo', 'option'); ?>" alt="">
                 	<?php the_content(); ?> 
              	</div>
           	</div>
       	</div>
        <div class="row align-items-center">
            <?php 
                $args = [
                    'post_type' => 'post',
                    'posts_per_page' => -1,
                    'orderby' => 'date',
                    'order' => 'DESC'
                ];
                $query = new WP_Query($args);
                if($query->have_posts()): while($query->have_posts()): $query->the_post();
            ?>
           	<div class="col-md-4 col-sm-12">
              	<div class="inner-dripping-card">
              	    <div class="drip-image">
                 	    <img src="<?php echo get_the_post_thumbnail_url(get_the_ID()); ?>" alt="dripping-spring"> 
                 	</div>
              	    <div class="drip-content">
                     	<h5><?php the_title(); ?></h5>
                     	<?php the_excerpt(); ?>
                     	<a href="<?php the_permalink(); ?>">SEE MORE</a>
                 	</div>
              	</div>
           	</div>
           	<?php endwhile;
           	wp_reset_query(); 
           	endif; ?> 
        </div>
 	</div>
</div> 

<?php include get_template_directory() . '/includes/section-wild-experience.php'; ?>

 <?php endwhile; endif;
get_footer(); ?>   