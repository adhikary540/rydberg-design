<?php
/*
* Template Name: Template Contact 
*/
get_header();
?> 
<?php if(have_posts()): while(have_posts()): the_post(); ?>

<div class="inner-page-main-sec">
 	<div class="container">
        <div class="row align-items-center">
           	<div class="col-md-12 col-sm-12">
              	<div class="contact-main-sec">  
                 	<?php the_content(); ?>
                 	<h5><?php echo get_field('wildflower_contact_number', 'option'); ?></h5>
              	</div> 
              	<div class="contact-form-sec"> 
              	    <button class="drop-note">Drop Us A Note</button> 
              	    <?php echo do_shortcode('[contact-form-7 id="74c743f" title="Contact Form"]'); ?>
              	</div>
           	</div>  
        </div>
 	</div>
</div> 

<?php include get_template_directory() . '/includes/section-client-story.php'; ?>
      
<?php endwhile; endif;
get_footer(); ?>     

      
      
