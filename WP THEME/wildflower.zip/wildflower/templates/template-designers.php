<?php 
/*Template Name: Template Designers*/
get_header(); ?>
<section class="inner-page-main-sec">
    <div class="container our-exclusive">
        <?php 
            $args = [
                'post_type' => 'designers',
                'orderby' => 'title',
                'order' => 'ASC',
                'posts_per_page' => -1,
            ];
            $query = new WP_Query($args);
            $i = 1;
            if($query->have_posts()): while($query->have_posts()): $query->the_post();
                $add_class = ($i % 2 == 0)?'flex-row-reverse d-flex designer-row-wrapper':'';
        ?>
        <div class="row <?php echo $add_class; ?>">
            <div class="col-lg-5">
                <div class="designer-listcontent-wrap">
                    <h2><?php the_title(); ?></h2>
                    <p class="location"><?php echo get_field('wildflower_designer_location'); ?></p>
                    <div class="pricing-wrap">
                        <p class="price"><?php echo get_field('wildflower_designer_price_range'); ?></p>
                    </div>
                    <div class="content">
                        <?php the_excerpt(); ?>
                    </div> 
                    <div class="designer-btn-wrap">
                        <a href="<?php echo get_field('wildflower_designer_website_link'); ?>" class="visit-site-btn">Visit Website</a>
                        <a href="<?php the_permalink(); ?>" class="book-now-btn">Book Now<img src="<?php bloginfo('template_url'); ?>/assets/images/right-book-now.svg"></a>
                    </div>
                </div>
            </div>
            <div class="col-lg-7">
                <div class="designer-listimg-wrap">
                    <img src="<?php echo get_field('wildflower_designer_list_image'); ?>">
                </div>
            </div>
        </div>
        <?php $i++; endwhile;
        wp_reset_query();
        endif; ?>
    </div>
</section>
<?php get_footer(); ?>