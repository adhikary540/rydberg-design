<?php 
/*Template Name: Template Book Now*/
get_header(); 
$front_page_id = get_option('page_on_front'); ?>
<div class="booking-sec large-min-height">
 	<div class="container">
        <div class="bookingWrap">
           	<div class="bookingDesc">
              	<h2><?php echo get_field('wildflower_booking_section_heading', $front_page_id); ?></h2>
              	<p><?php echo get_field('wildflower_booking_section_sub_heading', $front_page_id); ?></p>
              	<p><strong><i><?php echo get_field('wildflower_booking_section_details_text', $front_page_id); ?></i></strong></p>
           	</div>
           	<div class="bookingStep">
           	    <div class="bookingtop">
                <ul>
                    <li>
                        <span>01</span>
                        <p>Step 1 Select Appointment</p>
                    </li>
                    <li>
                        <span>02</span>
                        <p>Step 2 Contact Details</p>
                    </li>
                </ul>
                </div>
              	<?php echo do_shortcode('[contact-form-7 id="c403bad" title="Book Appointment"]');?>
           	</div>
        </div>
 	</div>
</div>
<?php get_footer();?>