<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Custom_Theme
 */

?>
<footer class="footer">
 	<div class="container">
        <div class="ftMenu">
           	<?php wp_nav_menu(array('theme_location'=>'menu-2','menu_class'=>'','container_class'=>'','container'=>'')); ?>
        </div>
        <div class="bottomFooter">
           	<div class="row">
              	<div class="col-md-4 col-sm-12">
                 	<div class="ftBox">
                    	<h3>social</h3>
	                    <ul class="ftSocial">
	                        <?php if(!empty(get_field('wildflower_xhandle_link', 'option'))){ ?>
	                       	    <li><a href="<?php echo get_field('wildflower_xhandle_link', 'option'); ?>" target="_blank"><i class="fa-brands fa-x-twitter"></i></a></li>
	                       	<?php } if(!empty(get_field('wildflower_facebook_link', 'option'))){ ?>
	                       	    <li><a href="<?php echo get_field('wildflower_facebook_link', 'option'); ?>" target="_blank"><i class="fa-brands fa-facebook-f"></i></a></li>
	                       	<?php } if(!empty(get_field('wildflower_instagram_link', 'option'))){ ?>
	                       	    <li><a href="<?php echo get_field('wildflower_instagram_link', 'option'); ?>" target="_blank"><i class="fa-brands fa-instagram"></i></a></li>
	                       	<?php } if(!empty(get_field('wildflower_tiktok_link', 'option'))){ ?>
	                       	    <li><a href="<?php echo get_field('wildflower_tiktok_link', 'option'); ?>" target="_blank"><i class="fa-brands fa-tiktok"></i></a></li>
	                       	<?php } if(!empty(get_field('wildflower_youtube_link', 'option'))){ ?>
	                       	    <li><a href="<?php echo get_field('wildflower_youtube_link', 'option'); ?>" target="_blank"><i class="fa-brands fa-youtube"></i></a></li>
	                       	<?php } ?>
	                    </ul>
                 	</div>
              	</div>
              	<div class="col-md-4 col-sm-12">
                 	<div class="ft-logo">
                    	<a href="<?php echo site_url(); ?>">
                       		<img src="<?php echo get_field('wildflower_footer_logo', 'option'); ?>" alt="">
                    	</a>
                 	</div>
                 	<div class="ftDesc">
                    	<p><?php echo get_field('wildflower_contact_address', 'option'); ?></p>
                 	</div>
              	</div>
              	<div class="col-md-4 col-sm-12">
                 	<div class="newsLetter">
                    	<h3>newsletter</h3>
	                    <div class="newLetFiel">
	                       	<div class="icon">
	                          	<i class="fa-regular fa-envelope"></i>
	                       	</div>
	                       	<form class="form-inline" method="post" action="<?php echo esc_url( home_url( '/' ) ); ?>?na=s" onsubmit="return newsletter_check(this)">
	                       	    <input type="email" placeholder="Email Address..." required name="ne" id="" class="form-control">
	                       	    <button type="submit" class="btn"><i class="fa-solid fa-angle-right"></i></button>
	                       	</form>
	                    </div>
                 	</div>
              	</div>
           	</div>
        </div>
 	</div>
</footer>

<div class="coppyRight">
 	<div class="container">
    	<p><?php echo get_field('wildflower_copyright_text', 'option'); ?></p>
 	</div>
</div>
<div class="go-top">
 	<svg class="svg-inline--fa fa-arrow-up" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="arrow-up" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512" data-fa-i2svg="">
    	<path fill="currentColor" d="M214.6 41.4c-12.5-12.5-32.8-12.5-45.3 0l-160 160c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L160 141.2V448c0 17.7 14.3 32 32 32s32-14.3 32-32V141.2L329.4 246.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3l-160-160z"></path>
 	</svg>
     <!-- <i class="fa-solid fa-arrow-up"></i> Font Awesome fontawesome.com -->
</div>

<div id="search-overlay" class="search-modal">
 	<div class="centered">
        <div id='search-box'>
           	<i id="close-btn" class="fa fa-times fa-2x"></i>
           	<form action='' id='search-form' method='' target=''>
              	<input id='search-text' name='' placeholder='Search' type='text' />
              	<button id='search-button' type='submit' class="btn">                     
              		<i class="fa-solid fa-magnifying-glass"></i>
              	</button>
           	</form>
        </div>
 	</div>
</div>
<?php wp_footer(); ?>

</body>
</html>
