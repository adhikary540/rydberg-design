<?php $front_page_id = get_option('page_on_front'); ?>
<div class="client-stories-sec">
	<div id="clientstoriesSlider" class="owl-carousel">
	    <?php if( have_rows('wildflower_client_story_list', $front_page_id) ): 
        while( have_rows('wildflower_client_story_list', $front_page_id) ) : the_row();?>
        <div class="item">
           <div class="container">
              <div class="row align-items-center">
                 <div class="col-xl-7 col-lg-7 col-md-12">
                    <div class="clientStoriesWrap">
                       <h3><?php the_sub_field('wildflower_client_story_section_heading'); ?></h3>
                       <?php the_sub_field('wildflower_client_story_details'); ?>
                       <h6><?php the_sub_field('wildflower_client_name'); ?></h6>
                       <div class="descImg">
                          <img src="<?php bloginfo('template_url'); ?>/assets/images/ft-logo.png" alt="">
                       </div>
                    </div>
                 </div>
                 <div class="col-xl-5 col-lg-5 col-md-12">
                    <div class="tham">
                       <img src="<?php the_sub_field('wildflower_client_right_image'); ?>" alt="">
                    </div>
                 </div>
              </div>
           </div>
        </div>
        <?php endwhile; 
        endif; ?>
     </div>
</div>

<div class="instagram-sec">
    <?php 
    $images = get_field('wildflower_gallery_images', $front_page_id);
    $size = 'full'; // (thumbnail, medium, large, full or custom size)
    if( $images ): ?>
        <ul>
            <?php foreach( $images as $image_url ): ?>
                <li>
                    <img src="<?php echo $image_url; ?>">
                </li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
</div>