<?php $front_page_id = get_option('page_on_front'); 
$add_background = (!is_front_page())?'added_backgrond':'';
?>
<div class="wild-flower-sec <?php echo $add_background; ?>">
 	<div class="container">
        <div class="row align-items-center">
           	<div class="col-md-6 col-sm-12">
              	<div class="wfImg">
                 	<img src="<?php echo get_field('wildflower_experience_section_left_image', $front_page_id); ?>" alt="">
              	</div>
           	</div>
           	<div class="col-md-6 col-sm-12">
              	<div class="wfDesc">
                 	<h2><?php echo get_field('wildflower_experience_section_heading', $front_page_id); ?></h2>
                 	<ul>
                 	    <?php if( have_rows('wildflower_experience_list', $front_page_id) ): 
  		                while( have_rows('wildflower_experience_list', $front_page_id) ) : the_row();?>
                        	<li><?php the_sub_field('wildflower_experience_details'); ?></li>
                        <?php endwhile; 
                        endif; ?>
                 	</ul>
                 	<h5><?php echo get_field('wildflower_experience_tagline_text', $front_page_id); ?></h5>
              	</div>
           	</div>
        </div>
 	</div>
</div>