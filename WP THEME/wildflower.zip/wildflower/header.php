<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Custom_Theme
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Pinyon+Script&display=swap" rel="stylesheet">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<header class="header">
	<div class="topHeader">
	    <div class="container">
	       <div class="topHeaderSlider">
	            <div id="HeaderSlider" class="owl-carousel">
                    <?php if( have_rows('wildflower_top_header_text_list', 'option') ): 
	          		while( have_rows('wildflower_top_header_text_list', 'option') ) : the_row();?>
             	    <div class="item">
                        <p><?php the_sub_field('wildflower_top_header_text'); ?></p>
             	    </div>
                    <?php endwhile; 
    	     		endif; ?>
	            </div>
	        </div>
	    </div>
	 </div>
	 <div class="bottoHeader">
	    <div class="container">
	       <div class="bottoHeaderWrap">
	          <div class="stellarnav">
	             <?php wp_nav_menu(array('theme_location'=>'menu-1','menu_class'=>'','container_class'=>'','container'=>'')); ?>
	          </div>
	          <div class="logo">
	             <a href="<?php echo site_url(); ?>"><img src="<?php echo get_field('wildflower_header_logo', 'option'); ?>" alt="logo" class="img-fluid"></a>
	          </div>
	          <div class="hdsrc">
	             <button class="hdsrcBtn" id="search-btn"><i class="fa-solid fa-magnifying-glass"></i></button>
	          </div>
	       </div>
	    </div>
	</div>
</header>

<?php if ( !is_front_page() ) {	?>
<div class="inner-page-banner" style="background-image:url('<?php echo get_template_directory_uri();?>/assets/images/banner-inner-page.png');">
    <div class="container"> 
        <div class="row">
            <div class="col-xl-12  col-md-12 col-sm-12">
                <div class="banner-heading"> 
                    <h1><?php the_title();?></h1> 
                </div>
            </div>
        </div>
    </div>
</div> 
<?php } ?>

