<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Custom_Theme
 */

get_header();
?>
<div class="inner-page-main-sec">
 	<div class="container">
        <div class="row align-items-center">
           	<div class="col-md-6 col-sm-12">
              	<div class="inner-main-desc">
                 	<h2><?php the_title();?></h2> 
                 	<?php the_content();?>
              	</div>
           	</div>
           	<div class="col-md-6 col-sm-12">
              	<div class="inner-main-img"> 
                 	<!--<img src="https://shyamfuture.in/wild-flower/wp-content/uploads/2025/11/wild-flower-img.png" alt="">-->
                    <?php the_post_thumbnail( 'full' ); ?> 
              	</div>
           	</div> 
        </div>
 	</div>
</div>

<?php include get_template_directory() . '/includes/section-client-story.php'; ?>
<?php
get_footer();
