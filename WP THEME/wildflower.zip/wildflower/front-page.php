<?php get_header();
if(have_posts()): while(have_posts()): the_post(); ?>
<div class="banner">
    <div id="bannerSlider" class="owl-carousel">
        <?php if( have_rows('wildflower_banner_list') ): 
  		while( have_rows('wildflower_banner_list') ) : the_row();?>
        <div class="item">
           	<img src="<?php the_sub_field('wildflower_banner_image'); ?>" alt="banner" class="img-fluid">
           	<div class="desc">
              	<div class="container">
                 	<div class="row align-items-end">
                    	<div class="col-xl-8  col-md-7 col-sm-12">
                       		<div class="bannerTtl">
                          		<h1><?php the_sub_field('wildflower_banner_heading'); ?></h1>
                       		</div>
                    	</div>
                    	<div class="col-xl-4 col-md-5 col-sm-12">
                       		<div class="bannerContent">
                          		<p><?php the_sub_field('wildflower_banner_sub_heading'); ?></p>
                          		<a href="<?php the_sub_field('wildflower_book_appointment_link'); ?>">Book Appointment</a>
                       		</div>
                    	</div>
                 	</div>
              	</div>
           	</div>
        </div>
        <?php endwhile;
        endif; ?>
    </div>
</div>
<div class="exclusive-sec">
 	<div class="container">
        <h2><?php echo get_field('wildflower_designer_section_heading'); ?></h2>
        <div class="row">
            <?php 
                $args = [
                    'post_type' => 'designers',
                    'orderby' => 'title',
                    'order' => 'ASC',
                    'posts_per_page' => 5,
                ];
                $designer_qry = new WP_Query($args);
                if($designer_qry->have_posts()): while($designer_qry->have_posts()): $designer_qry->the_post();
            ?> 
           	<div class="col-20">
              	<a href="<?php the_permalink(); ?>">
                 	<div class="exclusiveBox">
                    	<div class="tham">
                       		<img src="<?php echo get_the_post_thumbnail_url(get_the_ID()); ?>" alt="">
                		</div>
                    	<div class="exclusiveContent">
                       		<h4><?php the_title(); ?> [<?php echo get_field('wildflower_designer_location'); ?>]</h4>
                    	</div>
                 	</div>
              	</a>
           	</div>
           	<?php endwhile;
           	wp_reset_query();
           	endif; ?>
        </div>
        <div class="site-btnWrap d-flex justify-content-center">
           	<a href="<?php echo get_field('wildflower_all_designers_link'); ?>" class="sitebtn">Explore All Designers</a>
        </div>
 	</div>
</div>
<div class="booking-sec">
 	<div class="container">
        <div class="bookingWrap">
           	<div class="bookingDesc">
              	<h2><?php echo get_field('wildflower_booking_section_heading'); ?></h2>
              	<p><?php echo get_field('wildflower_booking_section_sub_heading'); ?></p>
              	<p><strong><i><?php echo get_field('wildflower_booking_section_details_text'); ?></i></strong></p>
           	</div>
           	<div class="bookingStep">
           	    <div class="bookingtop">
                    <ul>
                        <li>
                            <span>01</span>
                            <p>Step 1 Select Appointment</p>
                        </li>
                        <li>
                            <span>02</span>
                            <p>Step 2 Contact Details</p>
                        </li>
                    </ul>
                </div>
              	<?php echo do_shortcode('[contact-form-7 id="c403bad" title="Book Appointment"]');?>
           	</div>
        </div>
 	</div>
</div>

<?php include get_template_directory() . '/includes/section-wild-experience.php'; ?>

<?php include get_template_directory() . '/includes/section-client-story.php'; ?>
<?php endwhile; endif;
get_footer(); ?>