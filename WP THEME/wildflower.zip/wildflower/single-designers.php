<?php 
get_header();
if(have_posts()): while(have_posts()): the_post(); 
?>
<section class="inner-page-main-sec">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <div class="designer-details-title-wrap">
                    <h2><?php the_title(); ?></h2>
                    <p class="location"><?php echo get_field('wildflower_designer_location'); ?></p>
                </div>
            </div>
            <div class="col-md-6 p-0">
                <div class="designer-pricing-wrap">
                    <p class="price"><?php echo get_field('wildflower_designer_price_range'); ?></p>
                </div> 
                <div class="designer-content-wrap">
                    <?php the_excerpt(); ?>
                </div>
            </div>
            <div class="col-md-3 p-0"> 
                <div class="designer-btn-wrap">
                    <a href="<?php echo get_field('wildflower_designer_website_link'); ?>" class="visit-site-btn">Visit Website</a>
                    <a href="<?php echo site_url(); ?>/book-appointment" class="book-now-btn">Book Now<img src="<?php echo site_url(); ?>/wp-content/themes/wildflower/assets/images/right-book-now.svg"></a>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="mashonary-gal-secwrap">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php echo do_shortcode( get_field( 'wildflower_gallery_shortcode' ) ); ?>
            </div>
        </div>
    </div>
</section>

<?php include get_template_directory() . '/includes/section-wild-experience.php'; ?>
<?php 
endwhile; endif;
get_footer(); 
?>