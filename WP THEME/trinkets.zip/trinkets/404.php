<?php
/**
 * Custom 404 Template for Mobile Repair Website
 * @package WordPress
 */

get_header();
?>

<!-- Bootstrap CDN (only if not already added) -->

<style>
@keyframes shake {
  0%, 100% { transform: rotate(0deg); }
  25% { transform: rotate(3deg); }
  50% { transform: rotate(-3deg); }
  75% { transform: rotate(2deg); }
}

.broken-phone {
  max-width: 180px;
  animation: shake 2s infinite;
}

.fade-in {
  animation: fadeIn 1.5s ease-in;
}

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
}

.btn-custom {
  background-color: #198754;
  color: #fff;
  border-radius: 30px;
  padding: 10px 25px;
  font-weight: 600;
}

.btn-custom:hover {
  background-color: #198754;
  color: #fff;
}
</style>

<div class="container text-center py-5 fade-in">

    <h1 class="display-5 text-success fw-bold">Oops! Page Not Found</h1>
    <p class="lead text-muted">
        Sorry, the page you are looking for doesn’t exist or has been moved.
    </p>

    <!-- 🔙 Back to Home button -->
    <a href="<?php echo home_url(); ?>" class="btn btn-custom mt-3">
        Back to Homepage
    </a>
</div>

<?php
get_footer();
