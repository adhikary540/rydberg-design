<?php
/**
 * Template for displaying WooCommerce product archives (Shop page)
 */

defined( 'ABSPATH' ) || exit;
get_header( 'shop' ); ?>

<div class="shop-items-section-body py-5">
<div class="custom-container">
    <?php
    // Get product categories
    $categories = get_terms( array(
        'taxonomy'   => 'product_cat',
        'hide_empty' => true,
        
    ) );
    ?>

    <!-- ====== Tabs Header ====== -->
    <ul class="nav nav-tabs d-none d-lg-flex tab-header" id="myTab" role="tablist">
    
        <?php foreach ( $categories as $category ): ?>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="tab-<?php echo esc_attr( $category->slug ); ?>" data-bs-toggle="tab" data-bs-target="#tab-pane-<?php echo esc_attr( $category->slug ); ?>" type="button" role="tab" aria-controls="tab-pane-<?php echo esc_attr( $category->slug ); ?>" aria-selected="false">
                    <?php echo esc_html( $category->name ); ?>
                </button>
            </li>
        <?php endforeach; ?>
    </ul>

    <!-- ====== Tab Content ====== -->
    <div class="tab-content accordion" id="myTabContent">

        <!-- === All Products Tab === -->
        <div class="tab-pane fade show active accordion-item" id="tab-pane-all" role="tabpanel" aria-labelledby="tab-all" tabindex="0">
            <h2 class="accordion-header d-lg-none" id="heading-all">
                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-all" aria-expanded="true" aria-controls="collapse-all">
                    All
                </button>
            </h2>
            <div id="collapse-all" class="accordion-collapse collapse show d-lg-block" aria-labelledby="heading-all" data-bs-parent="#myTabContent">
                <div class="accordion-body">
                    <div class="row g-4">
                        <?php
                        if ( wc_get_loop_prop( 'total' ) ) {
                            while ( have_posts() ) {
                                the_post();
                                wc_get_template_part( 'content', 'product' );
                            }
                        } else {
                            echo '<p>No products found.</p>';
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- === Category Tabs === -->
        <?php foreach ( $categories as $category ): ?>
            <div class="tab-pane fade accordion-item" id="tab-pane-<?php echo esc_attr( $category->slug ); ?>" role="tabpanel" aria-labelledby="tab-<?php echo esc_attr( $category->slug ); ?>" tabindex="0">
                <h2 class="accordion-header d-lg-none" id="heading-<?php echo esc_attr( $category->slug ); ?>">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-<?php echo esc_attr( $category->slug ); ?>" aria-expanded="false" aria-controls="collapse-<?php echo esc_attr( $category->slug ); ?>">
                        <?php echo esc_html( $category->name ); ?>
                    </button>
                </h2>
                <div id="collapse-<?php echo esc_attr( $category->slug ); ?>" class="accordion-collapse collapse d-lg-block" aria-labelledby="heading-<?php echo esc_attr( $category->slug ); ?>" data-bs-parent="#myTabContent">
                    <div class="accordion-body">
                        <div class="row g-4">
                            <?php
                            $category_products = new WP_Query( array(
                                'post_type'      => 'product',
                                'posts_per_page' => 8,
                                'tax_query'      => array(
                                    array(
                                        'taxonomy' => 'product_cat',
                                        'field'    => 'slug',
                                        'terms'    => $category->slug,
                                    ),
                                ),
                            ) );

                            if ( $category_products->have_posts() ):
                                while ( $category_products->have_posts() ): $category_products->the_post();
                                    wc_get_template_part( 'content', 'product' );
                                endwhile;
                                wp_reset_postdata();
                            else:
                                echo '<p>No products found in this category.</p>';
                            endif;
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>

    </div>
</div>
</div>
<?php get_footer( 'shop' ); ?>
