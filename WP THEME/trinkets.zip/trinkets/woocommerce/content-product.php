<?php
defined( 'ABSPATH' ) || exit;

global $product;
?>

<div class="col-lg-3 col-md-3 col-sm-6">
                                            <a href="<?php the_permalink(); ?>">
                                                <div class="shop-box">
                                                    <div class="shop-box-img">
                                                        <?php echo $product->get_image(); ?>
                                                    </div>
                                                    <div class="shop-box-text">
                                                        <h4><?php the_title(); ?></h4>
                                                        <?php
                                                         global $product;

                                                         // Get average rating (0–5)
                                                         $rating = $product->get_average_rating();

                                                         // Round rating to nearest whole number
                                                         $rating_count = round($rating);
                                                         ?>
                                                   <p class="star-rating">
                                                       <?php for ( $i = 1; $i <= 5; $i++ ) : ?>
                                                           <?php if ( $i <= $rating_count ) : ?>
                                                               <i class="fa-solid fa-star"></i>
                                                           <?php else : ?>
                                                               <i class="fa-regular fa-star"></i>
                                                           <?php endif; ?>
                                                       <?php endfor; ?>
                                                   </p>
                                                        <h6><?php echo $product->get_price_html(); ?></h6>
                                                        <a href="<?php echo esc_url( $product->add_to_cart_url() ); ?>" class="cumn-butn-body blue-butn">
                                                            Add to Cart
                                                        </a>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>

