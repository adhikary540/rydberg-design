<?php
/* Template Name: FAQ Page */
get_header();
?>

<section class="faq-section">
  <div class="custom-container">

    <div class="faq-wrapper">
      <?php
      // Query FAQs
      $args = array(
        'post_type'      => 'faq',
        'posts_per_page' => -1,
        'order'          => 'ASC',
        'orderby'        => 'date'
      );
      $faqs = new WP_Query($args);

      if ($faqs->have_posts()) :
        $i = 0;
        while ($faqs->have_posts()) : $faqs->the_post();
          $i++;
      ?>
          <div class="faq-item">
            <button class="faq-question" aria-expanded="false" aria-controls="faq-<?php echo $i; ?>">
              <?php the_title(); ?>
              <span class="faq-icon">+</span>
            </button>
            <div id="faq-<?php echo $i; ?>" class="faq-answer">
              <?php the_content(); ?>
            </div>
          </div>
      <?php
        endwhile;
        wp_reset_postdata();
      else :
        echo '<p>No FAQs found.</p>';
      endif;
      ?>
    </div>
  </div>
</section>

<style>
  .faq-section {
    padding: 50px 0;
  }
  .faq-heading {
    text-align: center;
    font-size: 2rem;
    margin-bottom: 30px;
  }
  .faq-wrapper {
    max-width: 90%;
    margin: 0 auto;
  }
  .faq-item {
    border-bottom: 1px solid #ddd;
    margin-bottom: 15px;
  }
  .faq-question {
    width: 100%;
    text-align: left;
    font-size: 18px;
    padding: 15px;
    border: none;
    cursor: pointer;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-family: "Raleway", sans-serif;
    font-weight: 700;
    background: #432B7C;
    border: 1px solid #432B7C;
    color: #fff;
}
  }
  .faq-icon {
    font-weight: bold;
    transition: transform 0.3s ease;
  }
  .faq-answer {
    display: none;
    padding: 15px;
    font-size: 16px;
    color: #555;
    background: #fff;
  }
  .faq-question.active .faq-icon {
    transform: rotate(45deg);
  }
  
  .faq-answer p {
     font-family: 'Raleway' ;
	font-weight: 400;
	font-size: 16px;
	line-height: 26px;
	letter-spacing: 0%;
	color: #171717;
	padding: 0px;
	margin: 0px 30px 0px 0px; 
  }
</style>

<script>
  document.addEventListener("DOMContentLoaded", function() {
    const faqButtons = document.querySelectorAll(".faq-question");

    faqButtons.forEach(btn => {
      btn.addEventListener("click", function() {
        const answer = this.nextElementSibling;

        // Toggle active state
        this.classList.toggle("active");

        if (answer.style.display === "block") {
          answer.style.display = "none";
          this.setAttribute("aria-expanded", "false");
        } else {
          answer.style.display = "block";
          this.setAttribute("aria-expanded", "true");
        }
      });
    });
  });
</script>

<?php
get_footer();
?>
