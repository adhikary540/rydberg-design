<?php 
/*
* Template Name: Gallery
*/
get_header();
?>

<div class="gallery-section wow fadeInDown">
  <div class="custome-container">
    <div class="heading"><?php echo get_field('gallery_heding');?></div>
     <?php echo get_field('gallery_sub_heading');?>

     <div class="gallery-row">
        <?php if( have_rows('gallery_all_repeter',11) ):
                   while( have_rows('gallery_all_repeter',11) ) : the_row(); 
            ?>
      <a class="example-image-link" href="<?php echo get_sub_field('gallery_image');?>" data-lightbox="example-set" data-title="<?php echo get_sub_field('gallery_title');?>">
        <div class="gallery-thumb">
          <img src="<?php echo get_sub_field('gallery_image');?>" alt=""/>
          <h6><?php echo get_sub_field('gallery_title');?></h6>
        </div>
      </a>
        <?php endwhile;endif;?>
      
     </div>

    
  </div>
</div>

<?php get_footer();?>
