<?php 
/*
* Template Name: About Us
*/
get_header();
?>


<section class="welcome-section py-5">
    <div class="container text-center">
        <h6 class="section-subtitle mb-3">
    Overview
    <span class="subtitle-line"></span>
</h6>
        <h2 class="section-title mb-4">
            Welcome to Trinkets, Tags and Treasures – your go–to shop for<br>
            handmade keepsakes, heartfelt tags, and thoughtful little treasures<br>
            that bring joy to everyday moments.
        </h2>


        <div class="welcome-images d-flex justify-content-center align-items-end">

            <!-- Left Image -->
            <div class="welcome-img welcome-img-left">
                <img src="<?php bloginfo('template_directory'); ?>/assets/images/Image (8).png" alt="Gift Image 1">
            </div>

            <!-- Middle Image -->
            <div class="welcome-img welcome-img-center mx-4">
                <img src="<?php bloginfo('template_directory'); ?>/assets/images/Image (9).png" alt="Gift Image 2">
            </div>

            <!-- Right Image -->
            <div class="welcome-img welcome-img-right">
                <img src="<?php bloginfo('template_directory'); ?>/assets/images/Image (18).png" alt="Gift Image 3">
            </div>

        </div>

        
    </div>
</section>


<section class="story-section py-5">
    <div class="container">
        <div class="story-box text-center">
            <p class="story-text">
                What started as a creative passion turned into a place where meaningful gifts and one-of-a-kind creations come to life. Every item in our store is carefully crafted with love, whether it's a motivational magnetic clothespin, a charming baby announcement, or a festive gift tag for your seasonal celebrations.
            </p>

            <p class="story-highlight">
                We believe in the power of small details.
            </p>

            <p class="story-text">
                The right tag can elevate a gift, a keepsake can capture a precious memory, and a handmade item can brighten someone’s day. That’s why we take pride in creating pieces that feel personal, purposeful, and unique.
            </p>
        </div>
    </div>
</section>

<!-- tag-section -->
      <section class="tag-box-section">
         <div class="custom-container">
            <div class="tag-box-section-inner">
                <?php 
                    $terms = get_field('category_listing',132);
                    if( $terms ): ?>
                      <?php foreach( $terms as $term ): ?>
                <a href="<?php echo esc_url( get_term_link( $term ) ); ?>">
               <div class="tag-box wow bounceInUp">
                  <div class="tag-box-image <?php the_field('product_category_bg_class', $term); ?>">
                     <img src="<?php the_field('product_category_image_url', $term); ?>" alt="">
                  </div>
                  <div class="tag-box-tittle">
                     <h6><a href="<?php echo esc_url( get_term_link( $term ) ); ?>"><?php echo esc_html( $term->name ); ?></a></h6>
                  </div>
               </div>
                </a>
                <?php endforeach; ?>
              <?php endif; ?>
          
            </div>
         </div>
      </section>
      <!-- tag-section -->



<section class="thankyou-section">
    <div class="container text-center">

        <!-- First intro paragraph (top text) -->
        <p class="thank-intro">
            Tags, Trinkets, and Treasures—are filled with inspiration for celebrating milestones,
            decorating spaces, or simply making someone smile. Whether you’re looking for something
            sweet and sentimental or fun and functional, we’re here to help you find it.
        </p>

        <!-- Divider line -->
        <hr class="thank-divider">

        <!-- Main thank-you block -->
        <div class="thank-content mt-5">
            <div class="thank-icon">
                <img src="<?php bloginfo('template_directory'); ?>/assets/images/Vector (2).png" alt="Heart Icon">
            </div>

            <h3 class="thank-text">
                Thank you for supporting a small business that’s big on creativity<br>
                and heart. We’re so happy you’re here.
            </h3>

            <p class="thank-sign">
                With gratitude,<br>
                <strong>The Trinkets, Tags and Treasures Team</strong>
            </p>
        </div>

    </div>
</section>


























<!-- Stronger Together Section -->
  <div class="strongertogether-section">
    <div class="strongertogetherbg"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/strongertogetherbg.png" class="img-fluid" alt=""></div>
  <div class="container-fluid">
    <div class="row">
        <div class="col-lg-12 col-md-12 col-12">
          <div class="strongertogether-left wow animate fadeInLeft">
              <h6><?php echo get_field('cleaner_sections_sub_title');?></h6>
              <h2><?php echo get_field('cleaner_sections_title_main');?></h2>
              <?php echo get_field('content_description');?>
            </div>
        </div>
     </div>

   </div>
</div>
<!-- Stronger Together Section End -->

<div class="cleanersavailable-section">
  <div class="container-fluid">

   <?php 
   $count = 0;
  if (have_rows('cleaner_sections', 387)): 
   while (have_rows('cleaner_sections', 387)): the_row(); ?>

        <div class="row mb-5">

                  <div class="col-lg-6 col-md-12 col-12">
                       <div class="cleanersavailable-img">
                          <img src="<?php echo get_sub_field('image'); ?>" alt="">
                       </div>     
                   </div>

                   <div class="col-lg-6 col-md-12 col-12">
                         <div class="cleanersavailable-text <?php echo get_sub_field('add_class'); ?>">
                          <?php echo get_sub_field('content', false, false); ?>

                         </div>
                   </div>

         </div>

         <?php    
             $count++;
             endwhile;
             endif;
          ?>
  </div>
</div>




 
<!-- Testimonial Section -->
<div class="container-fluid  wow animate fadeInUp">
<div class="testimonial-section">
    <h2><?php echo get_field('our_customers_feedback_title', 381); ?></h2>
    <?php echo get_field('our_customers_feedback_shortcode', 381); ?>

  <div class="owl-carousel testimonial-carousel owl-loaded owl-drag">

  <?php 
   $count = 0;
  if (have_rows('our_customers_feedback_repeter', 381)): 
   while (have_rows('our_customers_feedback_repeter', 381)): the_row(); ?>

    <div class="item">
      <div class="testimonialcard">
        <div class="testiuser-card">            
          <div class="testiuserimg">
            <img src="<?php echo get_sub_field('user_image'); ?>" alt="" title="">
          </div>
          <div class="testiusertext">
            <h6><?php echo get_sub_field('user_name'); ?></h6>
            <div class="starcard">
              <?php
                $stars = get_sub_field('user_stars');
                for ($i = 0; $i < $stars; $i++) {
                  echo '<a href="#"><i class="fa fa-star" aria-hidden="true"></i></a>';
                }
              ?>
            </div>
          </div>
        </div>

        <p><?php echo get_sub_field('user_text'); ?></p>
      </div>
    </div>

   <?php    
                   $count++;
                   endwhile;
                   endif;
                   ?>

</div>


  </div>
</div> 

<?php get_footer();?>