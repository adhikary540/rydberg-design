
<?php 
/*
* Template Name: Current Specials
*/
get_header();
?>

<section class="top-product-section">
         <div class="custom-container">
            <h2 class="wow animate zoomIn"><?php echo get_field('why_choose_us_title');?></h2>
            <div class="top-product-section-body">

    <!-- Dynamic Category Tabs -->
    <ul class="nav nav-tabs d-none d-lg-flex tab-header" id="myTab" role="tablist">

        <?php 
        $categories = get_field('multi_select_prodcut_category',132);
        // $categories = get_terms( array(
        //     'taxonomy'   => 'product_cat',
        //     'hide_empty' => true,
        // ));

        $first = true;
        foreach ( $categories as $category ): 
         $term = get_term_by('id', $category, 'product_cat');
      ?>
            <li class="nav-item" role="presentation">
                <button 
                    class="nav-link <?php echo $first ? 'active' : ''; ?>" 
                    id="tab-<?php echo esc_attr($term->slug); ?>"
                    data-bs-toggle="tab" 
                    data-bs-target="#pane-<?php echo esc_attr($term->slug); ?>"
                    type="button" 
                    role="tab" 
                    aria-controls="pane-<?php echo esc_attr($term->slug); ?>"
                    aria-selected="<?php echo $first ? 'true' : 'false'; ?>"
                >
                    <?php echo esc_html($term->name); ?>
                </button>
            </li>
        <?php 
        $first = false;
        endforeach; ?>
    </ul>

    <div class="tab-content accordion" id="myTabContent">
        <?php 
        $first = true;
        foreach ( $categories as $category ): 
         $term = get_term_by('id', $category, 'product_cat');
         ?>
            <div 
                class="tab-pane fade accordion-item <?php echo $first ? 'show active' : ''; ?>" 
                id="pane-<?php echo esc_attr($term->slug); ?>" 
                role="tabpanel" 
                aria-labelledby="tab-<?php echo esc_attr($term->slug); ?>" 
                tabindex="0"
            >
                <h2 class="accordion-header d-lg-none" id="heading-<?php echo esc_attr($term->slug); ?>">
                    <button class="accordion-button <?php echo $first ? '' : 'collapsed'; ?>" 
                        type="button" 
                        data-bs-toggle="collapse" 
                        data-bs-target="#collapse-<?php echo esc_attr($term->slug); ?>"
                        aria-expanded="<?php echo $first ? 'true' : 'false'; ?>"
                        aria-controls="collapse-<?php echo esc_attr($term->slug); ?>">
                        <?php echo esc_html($term->name); ?>
                    </button>
                </h2>

                <div 
                    id="collapse-<?php echo esc_attr($term->slug); ?>" 
                    class="accordion-collapse collapse <?php echo $first ? 'show d-lg-block' : 'd-lg-block'; ?>" 
                    aria-labelledby="heading-<?php echo esc_attr($term->slug); ?>" 
                    data-bs-parent="#myTabContent">
                    <div class="accordion-body">
                        <div class="accordion-body-section">    
                            <div class="owl-carousel shop-items-carousel owl-theme">
                                <?php
                                $loop = new WP_Query( array(
                                    'post_type'      => 'product',
                                    'posts_per_page' => 10,
                                    'tax_query'      => array(
                                        array(
                                            'taxonomy' => 'product_cat',
                                            'field'    => 'slug',
                                            'terms'    => $term->slug,
                                        ),
                                    ),
                                ));

                                if ( $loop->have_posts() ) :
                                    while ( $loop->have_posts() ) : $loop->the_post();
                                        global $product; ?>

                                        <div class="item">
                                            <a href="<?php the_permalink(); ?>">
                                                <div class="shop-box">
                                                    <div class="shop-box-img">
                                                        <?php echo $product->get_image(); ?>
                                                    </div>
                                                    <div class="shop-box-text">
                                                        <h4><?php the_title(); ?></h4>
                                                        <?php
                                                         global $product;

                                                         // Get average rating (0–5)
                                                         $rating = $product->get_average_rating();

                                                         // Round rating to nearest whole number
                                                         $rating_count = round($rating);
                                                         ?>
                                                   <p class="star-rating">
                                                       <?php for ( $i = 1; $i <= 5; $i++ ) : ?>
                                                           <?php if ( $i <= $rating_count ) : ?>
                                                               <i class="fa-solid fa-star"></i>
                                                           <?php else : ?>
                                                               <i class="fa-regular fa-star"></i>
                                                           <?php endif; ?>
                                                       <?php endfor; ?>
                                                   </p>
                                                        <h6><?php echo $product->get_price_html(); ?></h6>
                                                        <a href="<?php echo esc_url( $product->add_to_cart_url() ); ?>" class="cumn-butn-body blue-butn">
                                                            Add to Cart
                                                        </a>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    <?php endwhile;
                                    wp_reset_postdata();
                                else:
                                    echo '<p>No products found.</p>';
                                endif;
                                ?>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        <?php 
        $first = false;
        endforeach; ?>
    </div>
</div>
         </div>
      </section>
      <!-- Top Product-section -->
      
      
      <section class="category-specials-section py-5">
    <div class="custom-container">

        <div class="row gy-4">
<?php if( have_rows('current_specials_repeater') ):
               while( have_rows('current_specials_repeater') ) : the_row(); ?>
            <!-- Card 1 -->
            <div class="col-lg-6">
                <a href="<?php echo get_sub_field('current_specials_repeater_link');?>" class="special-card">
                    <div class="special-card-img">
                        <img src="<?php echo get_sub_field('current_specials_repeater_image');?>" alt="Christmas Specials">
                    </div>
                    <div class="special-card-content">
                        <h4><?php echo get_sub_field('current_specials_repeater_title');?></h4>
                        <?php echo get_sub_field('current_specials_repeater_description');?>
                    </div>
                    
                    <div class="special-card-arrow">
                            <img src="<?php bloginfo('template_directory'); ?>/assets/images/Vector (3).png" alt="Arrow Icon">
                    </div>

                    
                </a>
            </div>
<?php endwhile;endif;?>


        </div>

    </div>
</section>

<div class="custom-container">
  <div class="row">
<?php 
// Query latest 10 products
$args = array(
    'post_type'      => 'product',
    'posts_per_page' => 10,
);
$loop = new WP_Query( $args );

if ( $loop->have_posts() ) :
    while ( $loop->have_posts() ) : $loop->the_post();
        global $product;
?>

    <div class="col-lg-3 col-md-3 col-sm-6 mb-4">
        <a href="<?php the_permalink(); ?>">
            <div class="shop-box">
                <div class="shop-box-img">
                    <?php echo $product->get_image(); ?>
                </div>
                <div class="shop-box-text">
                    <h4><?php the_title(); ?></h4>

                    <?php
                    // Dynamic Rating
                    $rating = $product->get_average_rating();
                    $rating_count = round($rating);
                    ?>
                    <p class="star-rating">
                        <?php for ( $i = 1; $i <= 5; $i++ ) : ?>
                            <?php if ( $i <= $rating_count ) : ?>
                                <i class="fa-solid fa-star"></i>
                            <?php else : ?>
                                <i class="fa-regular fa-star"></i>
                            <?php endif; ?>
                        <?php endfor; ?>
                    </p>

                    <h6><?php echo $product->get_price_html(); ?></h6>

                    <a href="<?php echo esc_url( $product->add_to_cart_url() ); ?>" class="cumn-butn-body blue-butn">
                        Add to Cart
                    </a>
                </div>
            </div>
        </a>
    </div>

<?php 
    endwhile;
endif;
wp_reset_postdata();
?>
</div>
</div>

<?php 

get_footer();

?>
