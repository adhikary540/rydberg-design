<?php 
/*
* Template Name: Contact Us
*/
get_header();
?>

<section class="contactuscard-section">
         <div class="custom-container">
            <div class="row">
               <div class="col-lg-6 col-md-12 col-12">
                  <div class="dropus-line">
        <h2><?php echo get_field('info_title');?></h2>
        <p><?php echo get_field('info_description');?></p>
            <?php if( have_rows('contact_info_repeater_two', 'option') ):
               while( have_rows('contact_info_repeater_two', 'option') ) : the_row(); ?>
               
                     <div class="contact-card">
                      <div class="icon"><img src="<?php echo get_sub_field('contact_info_repeater_image_two');?>" alt=""></div>
                      <div class="card-details">
                        <h6><?php echo get_sub_field('contact_info_repeater_text_two');?></h6>
                        <h5><?php echo get_sub_field('contact_info_repeater_description_two',false,false);?></h5>
                      </div>
                    </div>
                    
            <?php endwhile;endif;?>
            
        
       
             </div>
               </div>
               <div class="col-lg-6 col-md-12 col-12">
                  <div class="dropus-line">
                     <h2><?php echo get_field('contact_us_title');?></h2>
                     <p><?php echo get_field('contact_us_sub_title');?></p>
                     <div class="quoteform">
                        <?php echo get_field('contact_us_description');?>
                     
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- ContactusCard Section End -->


<?php get_footer();?>