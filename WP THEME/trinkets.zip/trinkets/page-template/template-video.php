<?php
/**
 * Template Name: Video Page
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 * @subpackage SFT
 * @since SFT 1.0
 */

get_header();


?>
<div class="container youtube-gallery">
  <h2 class="text-center">Our YouTube Gallery</h2>

  <div class="row gy-4">
    <?php if( have_rows('youtube_video_repeter', 172) ): ?>
      <?php while( have_rows('youtube_video_repeter', 172) ): the_row(); ?>
        <div class="col-md-6">
          <div class="card shadow-sm border-0 h-100">
            <div class="ratio ratio-16x9">
              <?php echo get_sub_field('youtube_video_emb', false, false); ?>
            </div>
            <div class="card-body text-center">
              <h5 class="card-title mb-0">
                <?php echo esc_html( get_sub_field('youtube_video_title') ); ?>
              </h5>
            </div>
          </div>
        </div>
      <?php endwhile; ?>
    <?php else: ?>
      <p class="text-center text-muted">No videos found.</p>
    <?php endif; ?>
  </div>
</div>

<?php get_footer(); ?>
<?php get_footer(); ?>