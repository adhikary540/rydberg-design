<?php 
/*
* Template Name: Home
*/
get_header();
?>

      <!-- tag-section -->
      <section class="tag-box-section">
         <div class="custom-container">
            <div class="tag-box-section-inner">
                <?php 
                    $terms = get_field('category_listing');
                    if( $terms ): ?>
                      <?php foreach( $terms as $term ): ?>
                <a href="<?php echo esc_url( get_term_link( $term ) ); ?>">
               <div class="tag-box wow bounceInUp">
                  <div class="tag-box-image <?php the_field('product_category_bg_class', $term); ?>">
                     <img src="<?php the_field('product_category_image_url', $term); ?>" alt="">
                  </div>
                  <div class="tag-box-tittle">
                     <h6><a href="<?php echo esc_url( get_term_link( $term ) ); ?>"><?php echo esc_html( $term->name ); ?></a></h6>
                  </div>
               </div>
                </a>
                <?php endforeach; ?>
              <?php endif; ?>
          
            </div>
         </div>
      </section>
      <!-- tag-section -->
      <!-- categories-section -->
      <section class="categories-section">
         <div class="custom-container">
         <div class="categories-section-tittle">
            <h2 class="wow animate fadeInLeft"><?php echo get_field('our_popular_categories_title');?>
            </h2>
            <p class="wow animate fadeInUp"><?php echo get_field('our_popular_categories_subtitle');?>
            </p>
             <?php 
                                $link = get_field('our_popular_categories_link');
                                if( $link ): 
                                    $link_url = $link['url'];
                                    $link_title = $link['title'];
                                    $link_target = $link['target'] ? $link['target'] : '_self';
                            ?>
                                <a href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>" class="cumn-butn-body wht-butn wow animate fadeInRight"><?php echo esc_html( $link_title ); ?> <span><i class="fa fa-arrow-up" aria-hidden="true"></i></span>
                                </a>
                              <?php endif; ?> 



            
         </div>
         <div class="categories-section-body">
            <div class="row">
               <?php 
$terms = get_field('popular_category_listing');
if( $terms ):
    
    // Get FIRST category term
    $term = $terms[0];

    // ACF term meta fields
    $cat_img   = get_field('product_category_image_url', $term);
    $cat_title = $term->name;
    $cat_desc  = $term->description;
    $cat_link  = get_term_link($term);

    // fallback image
    $fallback_img = get_template_directory_uri() . "/assets/images/cata-1.png";
?>
    
<div class="col-lg-6 col-md-6 col-12">
    <div class="categories-box categories-big-img wow animate zoomIn">

        <a href="<?php echo esc_url($cat_link); ?>">
            <img src="<?php echo ($cat_img) ? $cat_img : $fallback_img; ?>" alt="">
        </a>

        <div id="overlay"></div>

        <div class="categories-box-text">
            <div class="categories-box-text-left">
                <h3><?php echo esc_html($cat_title); ?></h3>
                <h4>
                    <?php echo ($cat_desc) ? esc_html($cat_desc) : "Explore our categories"; ?>
                </h4>
            </div>

            <div class="categories-box-text-right">
                <a href="<?php echo esc_url($cat_link); ?>" class="link-arrow">
                    <i class="fa fa-arrow-up" aria-hidden="true"></i>
                </a>
            </div>
        </div>

    </div>
</div>

<?php endif; ?>

               <div class="col-lg-6 col-md-6 col-12">
                <?php 
                  $terms = get_field('popular_category_listing');
                  if( $terms && isset($terms[1]) ):
                      
                      // Get FIRST category term
                      $term = $terms[1];

                      // ACF term meta fields
                      $cat_img   = get_field('product_category_image_url', $term);
                      $cat_title = $term->name;
                      $cat_desc  = $term->description;
                      $cat_link  = get_term_link($term);

                      // fallback image
                      $fallback_img = get_template_directory_uri() . "/assets/images/cata-1.png";
                  ?>
                  <div class="categories-box categories-mid-img wow animate zoomIn">
                     <a href="<?php echo esc_url($cat_link); ?>">
            <img src="<?php echo ($cat_img) ? $cat_img : $fallback_img; ?>" alt="">
        </a>
                     <div id="overlay"></div>
                     <div class="categories-box-text">
                        <div class="categories-box-text-left">
                           <h3><?php echo esc_html($cat_title); ?></h3>
                           <h4><?php echo ($cat_desc) ? esc_html($cat_desc) : "Explore our categories"; ?></h4>
                        </div>
                        <div class="categories-box-text-right">
                           <a href="javascript:void(0)" class="link-arrow"><i class="fa fa-arrow-up" aria-hidden="true"></i></a>
                        </div>
                     </div>
                  </div>
                  <?php endif; ?>
                  <div class="row">

                          <?php 
                                $terms = get_field('popular_category_listing');

                                if( $terms ):
                                    $count = 0;
                                    // print_r($terms);
                                    foreach( $terms as $index => $term ):

                                        // skip first 2 categories
                                        if( $index < 2 ) continue;

                                        // ACF Image
                                        $cat_img   = get_field('product_category_image_url', 'product_cat_'.$term->term_id);
                                          // echo $cat_img;
                                        // WC Category Title & Description
                                        $cat_title = $term->name;
                                        $cat_desc  = $term->description;
                                        $cat_link  = get_term_link($term);

                                        // Fallback per item
                                        $fallback_img = get_template_directory_uri() . "/assets/images/cata-3.png";
                                ?>
                                <div class="col-lg-6 col-md-6 col-12">
                                    <div class="categories-box categories-sml-img wow animate zoomIn">

                                      <a href="<?php echo esc_url($cat_link); ?>">
                                        
                                            <img src="<?php echo $cat_img ? $cat_img : $fallback_img; ?>" alt="">
                                        </a>

                                        <div id="overlay"></div>

                                        <div class="categories-box-text">
                                            <div class="categories-box-text-left">
                                                <h3><?php echo esc_html($cat_title); ?></h3>
                                                <h4> <?php echo ($cat_desc) ? esc_html($cat_desc) : "Explore our categories"; ?></h4>
                                            </div>
                                            <div class="categories-box-text-right">
                                                <a href="<?php echo esc_url($cat_link); ?>" class="link-arrow">
                                                    <i class="fa fa-arrow-up" aria-hidden="true"></i>
                                                </a>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <?php 
                                    endforeach;
                                endif;
                                ?>


                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- categories-section -->
      <!-- New Arrivals section -->
      <section class="new-arrivals">
         <div class="custom-container">
            <h2 class="wow animate zoomIn">New Arrivals</h2>
            <div class="owl-carousel new-arrivals-carousel owl-theme wow animate fadeInLeft">

<?php
$args = array(
    'post_type'      => 'product',
    'posts_per_page' => -1,
    'tax_query'      => array(
        array(
            'taxonomy' => 'product_visibility',
            'field'    => 'name',
            'terms'    => 'featured',
        ),
    ),
);

$featured_products = new WP_Query($args);

if ( $featured_products->have_posts() ):
    while ( $featured_products->have_posts() ): 
        $featured_products->the_post();
        global $product;

        $title = get_the_title();
        $link  = get_permalink();
        $price = $product->get_price_html();

        $img_url = get_the_post_thumbnail_url(get_the_ID(), 'medium');
        $fallback_img = get_template_directory_uri() . "/assets/images/arv-1.png";
?>
    <div class="item">
        <a href="<?php echo esc_url($link); ?>">
            <div class="arrivals-box">

                <div class="arrivals-box-img">
                    <img src="<?php echo $img_url ? $img_url : $fallback_img; ?>" alt="">
                </div>

                <div class="arrivals-box-text">
                    <h4><?php echo esc_html($title); ?></h4>
                    <h5><?php echo $price ? $price : '$0'; ?></h5>
                </div>

            </div>
        </a>
    </div>
<?php
    endwhile;
endif;

wp_reset_postdata();
?>

</div>

         </div>
      </section>
      <!-- New Arrivals section -->
      <!-- New Arrivals section -->
      <!-- premium-quality-section -->
      <section class="premium-quality-section">
         <div class="custom-container">
            <div class="premium-quality-section-top">
               <div class="premium-quality-section-top1">
                  <div class="row">
                     <div class="col-lg-3 col-md-3 col-12">
                        <div class="premium-quality-section-top1-left">
                           <h2 class="wow animate fadeInLeft"><?php echo get_field('modern_solutions_title');?></h2>
                        </div>
                     </div>
                     <div class="col-lg-9 col-md-9 col-12">
                        <div class="premium-quality-section-top1-right">
                           <img src="<?php bloginfo('template_directory'); ?>/assets/images/yel-box-icon.png" alt="" class="wow animate fa-angle-double-up">
                           <?php echo get_field('modern_solutions_right_description');?>
                          <!--  <p class="wow animate fadeInUp"><span>Welcome to Trinkets,</span> Tags and Treasures – your go-to shop for handmade keepsakes, 
                              heartfelt tags, and thoughtful little treasures that bring joy to everyday moments. 
                           </p>
                           <p class="wow animate fadeInUp">What started as a creative passion turned into a place where meaningful gifts and one-of-a-kind creations 
                              come to life. Every item in our store is carefully crafted with love, whether it's a motivational magnetic 
                              clothespin, a charming baby announcement, or a festive gift tag for your seasonal celebrations.
                           </p> -->
                        </div>
                     </div>
                  </div>
               </div>
               <div class="premium-quality-section-top2">
                  <div class="premium-quality-section-top2-img1 wow animate fadeInLeft">
                     <img src="<?php echo get_field('modern_solutions_image_1');?>" alt="">   
                  </div>
                  <div class="premium-quality-section-top2-img2 wow animate fadeInUp">
                     <img src="<?php echo get_field('modern_solutions_image_3');?>" alt="" class="img-tag rotateIn wow animate" data-wow-delay="0.5s" style="visibility: visible; animation-delay: 0.5s; animation-name: rotateIn;"> 
                     <img src="<?php echo get_field('modern_solutions_image_2');?>" alt=""> 
                  </div>
                  <div class="premium-quality-section-top2-img3 wow animate fadeInRight"> 
                     <img src="<?php echo get_field('modern_solutions_image_4');?>" alt=""> 
                  </div>
               </div>
            </div>
            
            <div class="premium-quality-section-icon"> 
    <div class="row">
        <?php if ( have_rows('premium_quality_repeater') ) : 
            $delay = 0.1; // starting delay
            while ( have_rows('premium_quality_repeater') ) : the_row(); 

                // Subfields
                $img      = get_sub_field('premium_quality_repeter_image');
                $title    = get_sub_field('premium_quality_repeter_text');
                $content  = get_sub_field('premium_quality_repeter_sub_text');

                // Handle both Array and URL
                if (is_array($img)) {
                    $img_url = $img['url'];
                } elseif (is_string($img)) {
                    $img_url = $img;
                } else {
                    $img_url = '';
                }
        ?>
            <div class="col-lg-4 col-4 col-12">
                <div class="premium-quality-icon-box wow bounceInUp"
                     data-wow-delay="<?php echo $delay; ?>s">

                    <div class="premium-quality-icon-box-img wow animate">
                        <?php if ($img_url) : ?>
                            <img src="<?php echo esc_url($img_url); ?>" alt="">
                        <?php endif; ?>
                    </div>

                    <div class="premium-quality-icon-box-text">
                        <?php if ($title) : ?>
                            <h4><?php echo esc_html($title); ?></h4>
                        <?php endif; ?>

                        <?php if ($content) : ?>
                            <p><?php echo esc_html($content); ?></p>
                        <?php endif; ?>
                    </div>

                </div>
            </div>

        <?php 
            $delay += 0.4; // 0.1 → 0.5 → 0.9
            endwhile; 
        endif; ?>
    </div>
</div>

         </div>
      </section>
      <!-- premium-quality-section -->
      <!-- Top Product-section -->
      <section class="top-product-section">
         <div class="custom-container">
            <h2 class="wow animate zoomIn"><?php echo get_field('why_choose_us_title');?></h2>
            <div class="top-product-section-body">

    <!-- Dynamic Category Tabs -->
    <ul class="nav nav-tabs d-none d-lg-flex tab-header" id="myTab" role="tablist">

        <?php 
        $categories = get_field('multi_select_prodcut_category');
        // $categories = get_terms( array(
        //     'taxonomy'   => 'product_cat',
        //     'hide_empty' => true,
        // ));

        $first = true;
        foreach ( $categories as $category ): 
         $term = get_term_by('id', $category, 'product_cat');
      ?>
            <li class="nav-item" role="presentation">
                <button 
                    class="nav-link <?php echo $first ? 'active' : ''; ?>" 
                    id="tab-<?php echo esc_attr($term->slug); ?>"
                    data-bs-toggle="tab" 
                    data-bs-target="#pane-<?php echo esc_attr($term->slug); ?>"
                    type="button" 
                    role="tab" 
                    aria-controls="pane-<?php echo esc_attr($term->slug); ?>"
                    aria-selected="<?php echo $first ? 'true' : 'false'; ?>"
                >
                    <?php echo esc_html($term->name); ?>
                </button>
            </li>
        <?php 
        $first = false;
        endforeach; ?>
    </ul>

    <div class="tab-content accordion" id="myTabContent">
        <?php 
        $first = true;
        foreach ( $categories as $category ): 
         $term = get_term_by('id', $category, 'product_cat');
         ?>
            <div 
                class="tab-pane fade accordion-item <?php echo $first ? 'show active' : ''; ?>" 
                id="pane-<?php echo esc_attr($term->slug); ?>" 
                role="tabpanel" 
                aria-labelledby="tab-<?php echo esc_attr($term->slug); ?>" 
                tabindex="0"
            >
                <h2 class="accordion-header d-lg-none" id="heading-<?php echo esc_attr($term->slug); ?>">
                    <button class="accordion-button <?php echo $first ? '' : 'collapsed'; ?>" 
                        type="button" 
                        data-bs-toggle="collapse" 
                        data-bs-target="#collapse-<?php echo esc_attr($term->slug); ?>"
                        aria-expanded="<?php echo $first ? 'true' : 'false'; ?>"
                        aria-controls="collapse-<?php echo esc_attr($term->slug); ?>">
                        <?php echo esc_html($term->name); ?>
                    </button>
                </h2>

                <div 
                    id="collapse-<?php echo esc_attr($term->slug); ?>" 
                    class="accordion-collapse collapse <?php echo $first ? 'show d-lg-block' : 'd-lg-block'; ?>" 
                    aria-labelledby="heading-<?php echo esc_attr($term->slug); ?>" 
                    data-bs-parent="#myTabContent">
                    <div class="accordion-body">
                        <div class="accordion-body-section">    
                            <div class="owl-carousel shop-items-carousel owl-theme">
                                <?php
                                $loop = new WP_Query( array(
                                    'post_type'      => 'product',
                                    'posts_per_page' => 10,
                                    'tax_query'      => array(
                                        array(
                                            'taxonomy' => 'product_cat',
                                            'field'    => 'slug',
                                            'terms'    => $term->slug,
                                        ),
                                    ),
                                ));

                                if ( $loop->have_posts() ) :
                                    while ( $loop->have_posts() ) : $loop->the_post();
                                        global $product; ?>

                                        <div class="item">
                                            <a href="<?php the_permalink(); ?>">
                                                <div class="shop-box">
                                                    <div class="shop-box-img">
                                                        <?php echo $product->get_image(); ?>
                                                    </div>
                                                    <div class="shop-box-text">
                                                        <h4><?php the_title(); ?></h4>
                                                        <?php
                                                         global $product;

                                                         // Get average rating (0–5)
                                                         $rating = $product->get_average_rating();

                                                         // Round rating to nearest whole number
                                                         $rating_count = round($rating);
                                                         ?>
                                                   <p class="star-rating">
                                                       <?php for ( $i = 1; $i <= 5; $i++ ) : ?>
                                                           <?php if ( $i <= $rating_count ) : ?>
                                                               <i class="fa-solid fa-star"></i>
                                                           <?php else : ?>
                                                               <i class="fa-regular fa-star"></i>
                                                           <?php endif; ?>
                                                       <?php endfor; ?>
                                                   </p>
                                                        <h6><?php echo $product->get_price_html(); ?></h6>
                                                        <a href="<?php echo esc_url( $product->add_to_cart_url() ); ?>" class="cumn-butn-body blue-butn">
                                                            Add to Cart
                                                        </a>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    <?php endwhile;
                                    wp_reset_postdata();
                                else:
                                    echo '<p>No products found.</p>';
                                endif;
                                ?>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        <?php 
        $first = false;
        endforeach; ?>
    </div>
</div>
         </div>
      </section>
      <!-- Top Product-section -->
      <!-- happy-client-section -->
      <section class="happy-client-section">
         <div class="custom-container">
         <h2 class="wow animate zoomIn"><?php echo get_field('testimonials_heding');?></h2>
            <div class="owl-carousel client-carousel owl-theme wow animate fadeInLeft">
               
              <?php if( have_rows('testimonials_repeater') ): ?>
               <?php while( have_rows('testimonials_repeater') ): the_row(); 
                  
                  // Get sub-field values  
                  $name        = get_sub_field('testimonials_name');
                  $description = get_sub_field('testimonials_description');
                  $rating      = get_sub_field('testimonials_rating_number'); // number 1–5

               ?>
      <div class="item"> 
         <div class="client-box">

            <h3>
               <?php 
                  // Print stars dynamically
                  if($rating){
                     for($i = 1; $i <= $rating; $i++){
                        echo '<i class="fa-solid fa-star"></i> ';
                     }
                  }
               ?>
            </h3>

            <p><?php echo esc_html($description); ?></p>
            <h5><?php echo esc_html($name); ?></h5>

         </div>
      </div>
   <?php endwhile; ?>
<?php endif; ?>

               
            </div>
         </div>
      </section>
      <!-- happy-client-section -->
      <!-- add-section -->
      <section class="add-section">
         <div class="custom-container">
            <div class="row">
               <div class="col-lg-5 col-md-5 col-12">
                  <div class="add-section-left wow animate fadeInLeft">
                     <h2><?php echo get_field('newsletter_title_left');?></h2>
                     <p><?php echo get_field('newsletter_left_description');?></p>
                         <?php 
                                $link = get_field('newsletter_left_link');
                                if( $link ): 
                                    $link_url = $link['url'];
                                    $link_title = $link['title'];
                                    $link_target = $link['target'] ? $link['target'] : '_self';
                            ?>
                                <a href="<?php echo esc_url( $link_url ); ?>" class="cumn-butn-body pink-butn" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a>
                              <?php endif; ?>
                  </div>
               </div>
               <div class="col-lg-7 col-md-7 col-12">
                  <div class="add-section-right wow animate fadeInRight">
                     <img src="<?php bloginfo('template_directory'); ?>/assets/images/subcrbe-bg.png" alt="">
                     <div id="overlay"></div>
                     <div class="add-section-right-inner">
                        <h2><?php echo get_field('newsletter_right_text');?></h2>
                        <p><?php echo get_field('newsletter_right_description');?></p>
                        <!--  <div class="newsletter-form">
                           <input type="email" name="email" placeholder="Enter your email address">
                           <input type="submit" value="Subscribe">
                        </div>  -->

                          <form class="form-inline" method="post" action="<?php echo esc_url( home_url( '/' ) ); ?>?na=s" onsubmit="return newsletter_check(this)"> 
                           <div class="newsletter-form">
                           <input type="email" placeholder="Enter your email" name="ne" required>
                           <button class="submit-btn" type="Subscribe">
                                                   Subscribe
                           </button>
                           </div>
                         </form>
                      
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- add-section -->


  
    <?php get_footer();?>