<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */

get_header();?>
<section class="about-section cmn-section">
<div class="custom-container">
<?php the_content(); 
?>
</div>
</section>
<?php 
get_footer();
