<?php
/**
 * The header.
 *
 * This is the template that displays all of the <head> section and everything up until main.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */
?>
<!doctype html>
<html <?php language_attributes(); ?> <?php twentytwentyone_the_html_classes(); ?>>
<head>
    <?php global $woocommerce; ?>
    <meta charset="<?php bloginfo( 'charset' ); ?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <?php wp_head(); ?>

</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>


<!-- header Section -->
      <header class="header-section">
         <div class="custom-container">
            <div class="row">
               <div class="col-lg-3 col-md-3 col-3">
                  <div class="logo"><a class="navbar-brand" href="<?php echo get_option('home'); ?>"><img class="" src="<?php the_field('header_logo', 'option'); ?>" alt="Trinkets-Tags-Treasures" title="Trinkets-Tags-Treasures" /></a></div>
               </div>
               <div class="col-lg-6 col-md-6 col-2">
                  <div id="main-nav" class="stellarnav">
                    <?php wp_nav_menu( array( 'theme_location' => 'primary', 'container'=> 'true' )); ?>
                   
                  </div>
               </div>
               <div class="col-lg-3 col-md-3 col-7">
                  <div class="rightlink">
                     <!--<div class="usercard"><a href="#"><img class="" src="<?php //bloginfo('template_directory'); ?>/assets/images/wishlist.png" alt="" title="" /></a></div>-->
                     <div class="usercard">
                        <div class="caunt"><?php echo esc_html( WC()->cart->get_cart_contents_count() ); ?></div>
                        <a href="<?php echo $woocommerce->cart->get_cart_url();?>"><img class="" src="<?php bloginfo('template_directory'); ?>/assets/images/bag.png" alt="" title="" /></a>
                     </div>
                     <div class="loging-butn">
                        <?php 
                            $account_url = get_permalink( get_option('woocommerce_myaccount_page_id') );
                            if ( is_user_logged_in() ) : ?>
                                <a href="<?php echo esc_url($account_url); ?>" class="cumn-butn-body black-butn">My Account</a>
                            <?php else : ?>
                                <a href="<?php echo esc_url($account_url); ?>" class="cumn-butn-body black-butn">Login</a>
                        <?php endif; ?>

                     </div>
                  </div>
               </div>
            </div>
         </div>
      </header>
      <!-- header Section -->
<?php 
if(is_front_page() ) {?>



    <!-- Banner Section -->
      <section class="banner-section">
         <div class="owl-carousel banner-carousel owl-theme">

            <?php 
              if( have_rows('banner_repeater') ):
                  while( have_rows('banner_repeater') ) : the_row(); 
              ?>

         <div class="item">
            <img src="<?php echo get_sub_field('banner_image');?>" alt="banner">
            <div id="overlay"></div>
            <div class="banner-text wow animate zoomIn">
                       <h1><?php echo get_sub_field('banner_text_rep');?></h1>
                        <?php echo get_sub_field('banner_sub_text_rep');?>

                       <div class="banner-srch-sec">

                          <?php aws_get_search_form( true ); ?>
                       </div>
               
               </div>
            </div>
            <?php endwhile;endif; ?>
         </div>
         
     
      </section>
      <!-- Banner Section End -->
   <?php } else if(is_page(268)) { ?>

      <div class="new-release-btn" style="
    background: #052D5E;
">About Us</div>

 <?php } else if(is_home()) { ?>
    <!-- blog -->
   <section class="inner-banner-section">
         <div class="overlay"> </div>
         <img src="<?php bloginfo('template_directory'); ?>/assets/images/inner-banner.png" alt="">
         <div class="container-fluid">
            <div class="inner-banner-text wow animate fadeInLeft" style="visibility: visible; animation-name: fadeInLeft;">
               <h1>Blog</h1>
            </div>
         </div>
      </section>
    

    <?php } else if( is_shop()) { ?>

      <div class="new-release-btn">Check Out Our new Releases</div>

     <?php } else if(is_product()) { ?>
    <!-- Shop -->

<div class="new-release-btn" style="
    background: #052D5E;
"><?php echo get_the_title(); ?></div>


      <?php } elseif(is_tax())  { ?>
      
      <div class="new-release-btn" style="
    background: #052D5E;
"><?php single_cat_title();?></div>





     
     <?php } elseif(is_category())  { ?>
     
     <!-- Banner Section -->
       <div class="new-release-btn" style="
    background: #052D5E;
"><?php single_cat_title();?></div>


    <!-- ====================================== -->
    <?php } else {?>
       <!-- Banner Section -->
       <div class="new-release-btn" style="
    background: #052D5E;
"><?php echo get_the_title(); ?></div>
     
        <?php }?>
