<?php 
/**
 * Template for Service Archive Page
 */
get_header(); 
?>

<section class="service-archive py-5">
  <div class="container">

    <div class="row">
      <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
        <div class="col-md-4 col-sm-6 col-12 mb-4">
          <div class="stratBox text-center h-100">
            <div class="tham mb-3">
              <?php if (has_post_thumbnail()) : ?>
                <img src="<?php echo get_the_post_thumbnail_url(get_the_ID(), 'medium'); ?>" alt="<?php the_title(); ?>" class="img-fluid rounded shadow-sm">
              <?php else : ?>
                <img src="<?php bloginfo('template_directory'); ?>/assets/images/default-service.png" alt="<?php the_title(); ?>" class="img-fluid rounded shadow-sm">
              <?php endif; ?>
            </div>
            <div class="text">
              <div class="ttl mb-3">
                <h3><?php the_title(); ?></h3>
              </div>
              <a href="<?php the_permalink(); ?>" class="btn btn-outline-primary btn-sm">Get Started</a>
            </div>
          </div>
        </div>
      <?php endwhile; else : ?>
        <div class="col-12 text-center">
          <p>No services available at the moment. Please check back later.</p>
        </div>
      <?php endif; ?>
    </div>

    <!-- Pagination -->
    <div class="pagination-wrapper text-center mt-5">
      <?php
      the_posts_pagination(array(
        'mid_size'  => 2,
        'prev_text' => __('← Previous', 'textdomain'),
        'next_text' => __('Next →', 'textdomain'),
      ));
      ?>
    </div>
  </div>
</section>

<?php get_footer(); ?>
