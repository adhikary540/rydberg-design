(function ($) {
    "use strict";
    

    // Mean Menu
    $('#main-nav').stellarNav({
        theme     :'plain',
        breakpoint: 1024,
        phoneBtn:false,
        locationBtn:false,
        sticky     :false,
        openingSpeed: 250,
        closingDelay: 250,
        position:'left',
        showArrows:true,
        closeBtn     :false,
        scrollbarFix:false,
        mobileMode:false
      
      });


      // $(document).ready(function() {
      //   $('.banner-carousel').owlCarousel({
      //     loop: true,
      //     margin: 0,
      //     // navText: ["<img src='assets/images/banner-Left.png'>","<img src='assets/images/banner-Right.png'>"],
      //     autoplay:true,
      //     responsiveClass: true,
      //     responsive: {
      //       0: {
      //         items: 1,
      //         nav: false
      //       },
      //       600: {
      //         items: 1,
      //         nav: false
      //       },
      //       1000: {
      //         items: 1,
      //         nav: false,
      //         loop: false,
      //         margin: 0
      //       }
      //     }
      //   })
      // })



      //Owl Carousel banner
$('.banner-carousel').owlCarousel({
  loop: true,
  autoplay:true,
  autoplayTimeout:5000,
  margin: 0,
  dots: true,
  nav: false,
  items: 1,
  // navText: ["<i class='fa fa-arrow-left'></i>","<i class='fa fa-arrow-right'></i>"],
  animateOut: 'fadeOut',
  animateIn: 'fadeIn',
})

//Owl Carousel banner



    
  $(document).ready(function() {
        $('.new-arrivals-carousel').owlCarousel({
          loop: true,
          margin: 30,
          autoplay:true,
          responsiveClass: true,
          responsive: {
            0: {
              items: 1,
              nav: true
            },
            600: {
              items: 3,
              nav: true
            },
            1000: {
              items: 5,
              nav: true,
              loop: true,
              margin:30,
            }
          }
        })
      })





  $(document).ready(function() {
        $('.shop-items-carousel').owlCarousel({
          loop: true,
          margin: 30,
          autoplay:true,
          responsiveClass: true,
          responsive: {
            0: {
              items: 1,
              nav: true
            },
            600: {
              items: 3,
              nav: true
            },
            1000: {
              items: 5,
              nav: true,
              loop: true,
              margin:30,
            }
          }
        })
      })







 $(document).ready(function() {
        $('.client-carousel').owlCarousel({
          loop: true,
          margin: 20,
          navText: ["<img src='https://shyamfuture.in/Trinkets/dev/wp-content/uploads/2025/11/Left-arrow.png'>","<img src='https://shyamfuture.in/Trinkets/dev/wp-content/uploads/2025/11/Right-arrow.png'>"],
          autoplay:true,
          responsiveClass: true,
          center: true,
          responsive: {
            0: {
              items: 1,
              nav: true
            },
            600: {
              items: 2,
              nav: true
            },
            1000: {
              items: 3,
              nav: true,
              loop: true,
              margin:20,
            }
          }
        })
      })






jQuery(document).ready(function($) {
        		"use strict";
        		//  TESTIMONIALS CAROUSEL HOOK
		        $('.client-carousel').owlCarousel({
		            loop: true,
		            center: true,
		            items: 3,
		            margin: 0,
		            autoplay: true,
		            dots:true,
		            autoplayTimeout: 8500,
		            smartSpeed: 450,
		            responsive: {
		              0: {
		                items: 1
		              },
		              768: {
		                items: 2
		              },
		              1170: {
		                items: 3
		              }
		            }
		        });
        	});
















    // Go to Top
    $(function () {
        // Scroll Event
        $(window).on("scroll", function () {
            var scrolled = $(window).scrollTop();
            if (scrolled > 600) $(".go-top").addClass("active");
            if (scrolled < 600) $(".go-top").removeClass("active");
        });
        // Click Event
        $(".go-top").on("click", function () {
            $("html, body").animate({ scrollTop: "0" }, 500);
        });
    });


    // WOW Animation JS
    if ($(".wow").length) {
        var wow = new WOW({
            mobile: false,
        });
        wow.init();
    }





})(jQuery);


