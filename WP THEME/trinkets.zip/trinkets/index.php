<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */

get_header(); ?>


	<?php get_header(); ?>
<div class="container">
<div class="cmn-page" data-aos="fade-up">
    <div class="custom-container">
        <div class="row">
            <!-- Left Blog Section -->
            <div class="col-lg-8 col-md-8 col-12">
                <div class="blog-page-left wow animate fadeInLeft">
                    <div class="row">
                        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                            <div class="col-lg-6 col-md-6 col-12">
                                <div class="blog-page-left-box">
                                    <div class="blog-page-left-box-img">
                                        <a href="<?php the_permalink(); ?>">
                                            <?php if (has_post_thumbnail()) : ?>
                                                <?php the_post_thumbnail('full'); ?>
                                            <?php else : ?>
                                                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/default-blog.png" alt="<?php the_title(); ?>">
                                            <?php endif; ?>
                                        </a>
                                    </div>
                                    <div class="blog-page-left-box-text">
                                        <h3><?php the_title(); ?></h3>
                                        <h6><a href="#"><span><img src="<?php echo get_template_directory_uri(); ?>/assets/images/calendr.png"></span><?php echo get_the_date(); ?></a></h6>
                                        <p><?php echo wp_trim_words(get_the_excerpt(), 13, '...'); ?></p>
                                        <a href="<?php the_permalink(); ?>" class="learn-btn">Read More <span><i class="fa-solid fa-arrow-right-long"></i></span></a>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; else : ?>
                            <p>No posts found.</p>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Pagination -->
                    <ul class="pagination pagination-md mt-3">
                        <li class="page-item"><?php previous_posts_link('&laquo; Previous'); ?></li>
                        <li class="page-item"><?php next_posts_link('Next &raquo;'); ?></li>
                    </ul>
                </div>
            </div>

            <!-- Right Sidebar -->
            <div class="col-lg-4 col-md-4 col-12">
                <div class="blog-page-right wow animate fadeInRight">
                    <!-- Recent Posts -->
                    <div class="recent-post">
                        <h3>Popular Posts</h3>
                        <?php 
                        $recent_posts = new WP_Query(array(
                            'posts_per_page' => 5,
                            'orderby' => 'date',
                            'order' => 'DESC'
                        ));
                        if ($recent_posts->have_posts()) :
                            while ($recent_posts->have_posts()) : $recent_posts->the_post(); ?>
                                <div class="recent-post-box">
                                    <div class="recent-post-box-img">
                                        <a href="<?php the_permalink(); ?>">
                                            <?php if (has_post_thumbnail()) : ?>
                                                <?php the_post_thumbnail('full'); ?>
                                            <?php else : ?>
                                                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/default-blog.png" alt="<?php the_title(); ?>">
                                            <?php endif; ?>
                                        </a>
                                    </div>
                                    <div class="recent-post-box-text">
                                        <p><?php the_title(); ?></p>
                                        <h6><?php echo get_the_date(); ?></h6>
                                    </div>
                                </div>
                            <?php endwhile;
                            wp_reset_postdata();
                        else : ?>
                            <p>No recent posts found.</p>
                        <?php endif; ?>
                    </div>

                    <!-- Categories -->
                    <div class="categories">
                        <h3>Categories</h3>
                        <ul>
                            <?php 
                            $categories = get_categories();
                            foreach ($categories as $category) {
                                echo '<li><a href="' . get_category_link($category->term_id) . '"><span><i class="fa-regular fa-circle"></i></span>' . $category->name . '</a></li>';
                            }
                            ?>
                        </ul>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</div>
</div>

<?php
get_footer();?>