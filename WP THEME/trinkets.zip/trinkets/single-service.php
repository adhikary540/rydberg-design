<?php 
/**
 * Single Service Template
 */
get_header(); 
?>

<section class="single-service-section py-5">
  <div class="container">
    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
      
      <div class="row">
        <!-- Image Column -->
        <div class="col-md-6 mb-4 mb-md-0">
          <?php if (has_post_thumbnail()) : ?>
            <img src="<?php echo get_the_post_thumbnail_url(get_the_ID(), 'large'); ?>" alt="<?php the_title(); ?>" class="img-fluid rounded shadow">
          <?php endif; ?>
        </div>

        <!-- Content Column -->
        <div class="col-md-6">
          <h1 class="service-title mb-3"><?php the_title(); ?></h1>
          <div class="service-content mb-4">
            <?php the_content(); ?>
          </div>

        
        </div>
      </div>

    <?php endwhile; endif; ?>
  </div>
</section>

<?php get_footer(); ?>
