<?php
/**
* A Simple Category Template
*/
 
get_header(); ?> 

 
<section id="primary" class="site-content">
<div id="content" role="main">
<div class="container">
<?php 
// Check if there are any posts to display
if ( have_posts() ) : 
	$categories = get_the_category();
	$category_id = $categories[0]->cat_ID;
	$category_name = get_cat_name($category_id);
?>
 
<header class="archive-header"><br>
 
 
<?php
// Display optional category description
 if ( category_description() ) : ?>
<div class="archive-meta"><?php echo category_description(); ?></div>
<?php endif; ?>
</header>
 
	<div class="row my-5">
<?php
 
// The Loop
while ( have_posts() ) : the_post(); ?>
		<div class="col-lg-6 col-md-6 col-12">
                                <div class="blog-page-left-box">
                                    <div class="blog-page-left-box-img">
                                        <a href="<?php the_permalink(); ?>">
                                            <?php if (has_post_thumbnail()) : ?>
                                                <?php the_post_thumbnail('full'); ?>
                                            <?php else : ?>
                                                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/default-blog.png" alt="<?php the_title(); ?>">
                                            <?php endif; ?>
                                        </a>
                                    </div>
                                    <div class="blog-page-left-box-text">
                                        <h3><?php the_title(); ?></h3>
                                        <h6><a href="#"><span><img src="<?php echo get_template_directory_uri(); ?>/assets/images/calendr.png"></span><?php echo get_the_date(); ?></a></h6>
                                        <p><?php echo wp_trim_words(get_the_excerpt(), 20, '...'); ?></p>
                                        <a href="<?php the_permalink(); ?>" class="learn-btn">Read More <span><i class="fa-solid fa-arrow-right-long"></i></span></a>
                                    </div>
                                </div>
                            </div>
<?php endwhile; 
 
else: ?>
<p>Sorry, no posts matched your criteria.</p>
 
 
<?php endif; ?>
</div></div></div>
</section>
 
 
<?php get_footer(); ?>