<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */

?>


<!-- footer Section  -->
      <footer class="footer">
         <div class="custom-container">
            <div class="footer-top">
               <div class="row">
                  <div class="col-lg-4 col-md-4 col-12">
                     <div class="footer-payment-section">
                        <h2><?php the_field('footer_title', 'option'); ?></h2>
                        <p><?php the_field('footer_content', 'option'); ?></p>
                        <span class="payment-img"><img src="<?php the_field('footer_logo', 'option'); ?>" alt=""></span>
                     </div>
                  </div>
                  <div class="col-lg-2 col-md-2 col-12">
                     <div class="footer-quick-links">
                        <h3>Company</h3>
                        <?php wp_nav_menu( array( 'theme_location' => 'footer', 'container'=> 'true' )); ?>
                        <!-- <ul>
                           <li><a href="javascript:void(0)" target="_blank">About Us</a></li>
                           <li><a href="javascript:void(0)" target="_blank">New Arrivals</a></li>
                           <li><a href="javascript:void(0)" target="_blank">Shop</a></li>
                           <li><a href="javascript:void(0)" target="_blank">Contact</a></li>
                        </ul> -->
                     </div>
                  </div>
                  <div class="col-lg-4 col-md-4 col-12">
                     <div class="footer-quick-links footer-quick-links2">
                        <h3>Products</h3>
                        <?php wp_nav_menu( array( 'theme_location' => 'footer1', 'container'=> 'true' )); ?>
                       <!--  <ul>
                           <li><a href="javascript:void(0)" target="_blank">Tags</a></li>
                           <li><a href="javascript:void(0)" target="_blank">Cutting Boards</a></li>
                           <li><a href="javascript:void(0)" target="_blank">Bottle Opener</a></li>
                           <li><a href="javascript:void(0)" target="_blank">Fridge Magnet</a></li>
                           <li><a href="javascript:void(0)" target="_blank">Spoon</a></li>
                           <li><a href="javascript:void(0)" target="_blank">Decor</a></li>
                           <li><a href="javascript:void(0)" target="_blank">Gift Box</a></li>
                           <li><a href="javascript:void(0)" target="_blank">Utility</a></li>
                        </ul> -->
                     </div>
                  </div>
                  <div class="col-lg-2 col-md-2 col-12">
                     <div class="footer-quick-links">
                        <h3>Follow Us</h3>
                        <ul>
                           <li><a href="<?php the_field('facebook', 'option'); ?>" target="_blank">Facebook</a></li>
                           <li><a href="<?php the_field('twitter', 'option'); ?>" target="_blank">Twitter</a></li>
                           <li><a href="<?php the_field('instagram', 'option'); ?>" target="_blank">Instagram</a></li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
            <div class="footer-butm">
               <div class="row">
                  <div class="col-lg-4 col-md-4 col-12">
                     <div class="footer-butm-left">
                        <p><?php the_field('footer_copyright_text', 'option'); ?></p>
                     </div>
                  </div>
                  <div class="col-lg-4 col-md-4 col-12">
                     <div class="footer-butm-menu">
                        <?php wp_nav_menu( array( 'theme_location' => 'footer2', 'container'=> 'true' )); ?>
                        <!-- <ul>
                           <li><a href="javascript:void(0)" target="_blank">Privacy Policy</a></li>
                           <li><a href="javascript:void(0)" target="_blank">Terms & Conditions</a></li>
                           <li><a href="javascript:void(0)" target="_blank">Cookie Policy</a></li>
                        </ul> -->
                     </div>
                  </div>
                  <div class="col-lg-4 col-md-4 col-12">
                     <div class="footer-butm-right">
                        <p><?php the_field('footer_copyright_text_left', 'option'); ?></p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </footer>
      <!-- footer Section  -->
    <div class="go-top active"><i class="fa fa-arrow-up" aria-hidden="true"></i></div>


<?php wp_footer(); ?>   



 <script>
         jQuery(window).scroll(function () {
               if (jQuery(this).scrollTop() > 50) {
                   jQuery('.header-section').addClass('scroll');
               } else {
                   jQuery('.header-section').removeClass('scroll');
               }
           });
      </script>

<script>
 jQuery(document).ready(function ($) {
    $(".nr-tabs .nav-link").on("click", function (e) {
        e.preventDefault();

        $(".nr-tabs .nav-link").removeClass("active");
        $(this).addClass("active");

        let cat = $(this).data("cat");

        $.ajax({
            url: wc_add_to_cart_params.ajax_url,
            type: "POST",
            data: {
                action: "nr_filter_products",
                category: cat
            },
            success: function (response) {
                $("#nr-product-grid").html(response);
            }
        });
    });
});


</script>
     

</body>
</html>
